package com.casparser.parser;

import static org.assertj.core.api.Assertions.*;
import com.casparser.domain.Statement.TransactionType;
import java.math.BigDecimal;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class TransactionClassifierTest {
    @ParameterizedTest
    @CsvSource(delimiter = '|', textBlock = """
            Purchase|1|PURCHASE
            SIP Purchase - Instalment 1|1|PURCHASE_SIP
            Redemption|-1|REDEMPTION
            SWP|1|REDEMPTION
            Switch In|1|SWITCH_IN
            STP Out|-1|SWITCH_OUT
            Merger Switch In|1|SWITCH_IN_MERGER
            Merger Switch Out|-1|SWITCH_OUT_MERGER
            IDCW Payout|0|DIVIDEND_PAYOUT
            Dividend Reinvestment|1|DIVIDEND_REINVEST
            Stamp Duty|0|STAMP_DUTY_TAX
            Securities Transaction Tax|0|STT_TAX
            TDS|0|TDS_TAX
            Segregated portfolio allotment|1|SEGREGATION
            Gift from folio 123|1|GIFT_IN
            Gift to folio 456|-1|GIFT_OUT
            Transmission In|1|TRANSMISSION_IN
            Transmission Out|-1|TRANSMISSION_OUT
            Purchase Reversal|-1|REVERSAL
            Rejected SIP|-1|REVERSAL
            Bonus allotment|1|BONUS
            Bank mandate changed|0|MISC
            Unfamiliar operation|1|UNKNOWN
            """)
    void orderedRules(String text, String units, TransactionType expected) {
        assertThat(new TransactionClassifier().classify(text, new BigDecimal(units))).isEqualTo(expected);
    }
}
