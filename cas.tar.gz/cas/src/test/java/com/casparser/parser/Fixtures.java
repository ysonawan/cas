package com.casparser.parser;

public final class Fixtures {
    private Fixtures() {}

    public static final String DETAILED = """
            CAMS
            Consolidated Account Statement
            Statement Period: 01-Apr-2024 to 31-Mar-2025
            Investor: SAMPLE INVESTOR
            Email: sample@example.test
            Address: 1 Example Road, Example City
            Mobile: +919999999999
            Example Mutual Fund
            Folio No: 12345678 / 90 PAN: ABCDE1234F KYC: OK PAN KYC: OK
            EX01-Example Flexi Cap Fund - Direct Plan - Growth (Advisor: DIRECT)
            ISIN: INF179K01VY8
            Registrar: CAMS
            Nominee: SAMPLE NOMINEE
            Opening Unit Balance: 10.000
            Date Description Amount Units NAV Balance
            02-Apr-2024 SIP Purchase - Instalment 1/12 1,000.00 10.000 100.00 20.000
            02-Apr-2024 *** Stamp Duty *** 0.05
            15-Apr-2024 Redemption (500.00) (5.000) 100.00 15.000
            Closing Unit Balance: 15.000
            NAV on 31-Mar-2025: 110.0000
            Market Value as on 31-Mar-2025: 1,650.00
            Cost of Investment: 1,500.00
            """;

    public static final String SUMMARY = """
            KFintech
            Consolidated Account Statement - Summary
            As on 31-Mar-2025
            Investor: SAMPLE INVESTOR
            Email: sample@example.test
            Example Mutual Fund
            Scheme Folio Units NAV Date NAV Market Value
            INF179K01VY8 Example Flexi Cap Fund - Direct Growth 12345678/90 15.000 31-Mar-2025 110.0000 1,650.00 CAMS
            Example Liquid Fund - Direct Growth 87654321 0.000 31-Mar-2025 100.00 0.00 KFINTECH
            Grand Total 1,650.00
            """;

    public static final String NSDL = """
            National Securities Depository Limited
            Consolidated Account Statement
            Statement Period: 01-Apr-2024 to 30-Apr-2024
            Investor: SAMPLE INVESTOR
            Email: sample@example.test
            DP Name: Example Broker
            DP ID: IN300001 Client ID: 00123456
            First Holder: SAMPLE INVESTOR PAN: ABCDE1234F
            Equities
            ISIN Security Name Quantity Market Price Market Value
            INE002A01018 Example Industries Limited 10 2,000.00 20,000.00
            Mutual Funds
            INF179K01VY8 Example Fund Direct Growth 100.000 110.00 11,000.00
            Bonds
            INE001A07010 Example Corporate Bond 2 1,000.00 2,000.00
            Account Value: 33,000.00
            """;

    public static final String CDSL = """
            Central Depository Services (India) Limited
            Consolidated Account Statement
            Statement Period: 01-Apr-2024 to 30-Apr-2024
            Investor: SAMPLE INVESTOR
            DP Name: Example Broker
            BO ID: 1200000000123456
            Equities
            INE002A01018 Example Industries Limited 10 2,000.00 20,000.00
            Account Value: 20,000.00
            National Pension System
            PRAN: 123456789012
            CRA: PROT
            Example Pension Fund Scheme E Tier I 100.000 20.00 2,000.00
            Total NPS Value: 2,000.00
            """;

    public static ParserEngine engine() {
        return new ParserEngine(new StatementDetector(), java.util.List.of(
                new MutualFundDetailedParser(), new MutualFundSummaryParser(), new DematParser()));
    }

    public static com.casparser.domain.Statement parse(String text) {
        return engine().parse(SourceDocument.fromText(text), false, new ParseContext(30_000, 500));
    }
}
