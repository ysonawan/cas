package com.casparser.parser;

import static org.assertj.core.api.Assertions.*;
import com.casparser.domain.ParseException;
import com.casparser.domain.Statement.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MutualFundParserTest {
    @ParameterizedTest @ValueSource(strings = {"CAMS", "KFintech", "Karvy"})
    void parsesDetailedIssuerVariants(String issuer) {
        var result = Fixtures.parse(Fixtures.DETAILED.replaceFirst("CAMS", issuer));
        assertThat(result.status()).isEqualTo(ParseStatus.COMPLETE);
        assertThat(result.fileType()).isEqualTo(issuer.equals("CAMS") ? FileType.CAMS : FileType.KFINTECH);
        assertThat(result.folios()).hasSize(1);
        var folio = result.folios().getFirst();
        assertThat(folio.folio()).isEqualTo("12345678/90");
        assertThat(folio.pan()).isEqualTo("ABCDE1234F");
        assertThat(folio.kyc()).isEqualTo("OK");
        var scheme = folio.schemes().getFirst();
        assertThat(scheme.transactions()).hasSize(3);
        assertThat(scheme.open()).isEqualByComparingTo("10");
        assertThat(scheme.closeCalculated()).isEqualByComparingTo("15");
        assertThat(scheme.valuation().value()).isEqualByComparingTo("1650");
        assertThat(scheme.nominees()).containsExactly("SAMPLE NOMINEE");
        assertThat(scheme.transactions().get(1).units()).isNull();
        assertThat(scheme.transactions().get(2).amount()).isEqualByComparingTo("-500");
    }

    @Test void wrappedTransactionAndPageBreak() {
        String source = Fixtures.DETAILED.replace("SIP Purchase - Instalment 1/12 1,000.00", "SIP Purchase -\n\fCAMS\nPage 2 of 2\nInstalment 1/12 1,000.00");
        var result = Fixtures.parse(source);
        assertThat(result.warnings()).isEmpty();
        assertThat(result.folios().getFirst().schemes().getFirst().transactions().getFirst().description()).contains("Instalment 1/12");
    }

    @Test void identicalTransactionsAreNotDeduplicated() {
        String row = "02-Apr-2024 SIP Purchase 1,000.00 10.000 100.00 20.000\n";
        var result = Fixtures.parse(Fixtures.DETAILED.replace("Closing Unit Balance", row + "Closing Unit Balance"));
        assertThat(result.metadata().parsedTransactions()).isEqualTo(4);
        assertThat(result.warnings()).extracting(Diagnostic::code).contains("CLOSING_BALANCE_MISMATCH");
    }

    @Test void warnsOnBadRunningBalanceAndStrictRejects() {
        String source = Fixtures.DETAILED.replace("100.00 20.000", "100.00 99.000");
        assertThat(Fixtures.parse(source).warnings()).extracting(Diagnostic::code).contains("RUNNING_BALANCE_MISMATCH");
        assertThatThrownBy(() -> Fixtures.engine().parse(SourceDocument.fromText(source), true, new ParseContext(30000, 100)))
                .isInstanceOfSatisfying(ParseException.class, e -> assertThat(e.code()).isEqualTo("STRICT_VALIDATION_FAILED"));
    }

    @Test void unknownRowsAreVisible() {
        String source = Fixtures.DETAILED.replace("SIP Purchase - Instalment 1/12", "Unfamiliar operation");
        var result = Fixtures.parse(source);
        assertThat(result.status()).isEqualTo(ParseStatus.PARTIAL);
        assertThat(result.warnings()).extracting(Diagnostic::code).contains("UNKNOWN_TRANSACTION");
        assertThat(result.metadata().parsedTransactions()).isEqualTo(3);
    }

    @Test void malformedTransactionDoesNotDisappearSilently() {
        String source = Fixtures.DETAILED.replace("1,000.00 10.000 100.00 20.000", "invalid amount 100.00 20.000");
        assertThat(Fixtures.parse(source).warnings()).extracting(Diagnostic::code).contains("UNPARSED_TRANSACTION", "CLOSING_BALANCE_MISMATCH");
    }

    @Test void missingOpeningIsNotInvented() {
        var result = Fixtures.parse(Fixtures.DETAILED.replace("Opening Unit Balance: 10.000\n", ""));
        assertThat(result.folios().getFirst().schemes().getFirst().open()).isNull();
        assertThat(result.folios().getFirst().schemes().getFirst().closeCalculated()).isNull();
        assertThat(result.warnings()).extracting(Diagnostic::code).contains("MISSING_OPENING_BALANCE");
    }

    @Test void noTransactionSchemeAndZeroBalanceAreRetained() {
        String source = """
                CAMS
                Consolidated Account Statement
                Statement Period: 01-Apr-2024 to 31-Mar-2025
                Investor: SAMPLE INVESTOR
                Example Mutual Fund
                Folio No: 123
                Scheme: Example Zero Fund
                Opening Unit Balance: 0.000
                No transactions during the period
                Closing Unit Balance: 0.000
                NAV on 31-Mar-2025: 100.00
                Market Value as on 31-Mar-2025: 0.00
                """;
        var result = Fixtures.parse(source);
        assertThat(result.warnings()).isEmpty();
        assertThat(result.folios().getFirst().schemes().getFirst().transactions()).isEmpty();
    }

    @ParameterizedTest @ValueSource(strings = {"CAMS", "KFintech", "Karvy"})
    void summaryRetainsAllFoliosAndZeroHoldings(String issuer) {
        var result = Fixtures.parse(Fixtures.SUMMARY.replaceFirst("KFintech", issuer));
        assertThat(result.casType()).isEqualTo(CasType.SUMMARY);
        assertThat(result.warnings()).isEmpty();
        assertThat(result.folios()).hasSize(2);
        assertThat(result.folios().get(1).schemes().getFirst().close()).isZero();
        assertThat(result.folios().getFirst().schemes().getFirst().isin()).isEqualTo("INF179K01VY8");
    }

    @Test void wrappedSummaryName() {
        var result = Fixtures.parse(Fixtures.SUMMARY.replace("Example Flexi Cap Fund - Direct Growth", "Example Flexi Cap Fund -\nDirect Growth"));
        assertThat(result.warnings()).isEmpty();
        assertThat(result.folios().getFirst().schemes().getFirst().scheme()).contains("Direct Growth");
    }

    @Test void sameFolioNumberAtDifferentAmcsDoesNotMerge() {
        String extra = """
                Another Mutual Fund
                Folio No: 12345678/90
                Scheme: Another Liquid Fund
                Opening Unit Balance: 0.000
                Closing Unit Balance: 0.000
                NAV on 31-Mar-2025: 1.00
                Market Value as on 31-Mar-2025: 0.00
                """;
        assertThat(Fixtures.parse(Fixtures.DETAILED + extra).folios()).hasSize(2);
    }

    @Test void unsignedRedemptionNormalizedByDirection() {
        var result = Fixtures.parse(Fixtures.DETAILED.replace("(500.00) (5.000)", "500.00 5.000"));
        assertThat(result.warnings()).isEmpty();
        assertThat(result.folios().getFirst().schemes().getFirst().transactions().get(2).units()).isEqualByComparingTo("-5");
    }
}
