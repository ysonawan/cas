package com.casparser.parser;

import static org.assertj.core.api.Assertions.*;
import com.casparser.domain.Statement.*;
import org.junit.jupiter.api.Test;

class DematParserTest {
    @Test void nsdlPreservesAssetsAndLeadingZeroIdentifiers() {
        var result = Fixtures.parse(Fixtures.NSDL);
        assertThat(result.fileType()).isEqualTo(FileType.NSDL);
        assertThat(result.warnings()).isEmpty();
        var account = result.accounts().getFirst();
        assertThat(account.clientId()).isEqualTo("00123456");
        assertThat(account.holdings()).extracting(Holding::assetType).containsExactly(AssetType.EQUITY, AssetType.MUTUAL_FUND, AssetType.BOND);
        assertThat(account.balance()).isEqualByComparingTo("33000");
        assertThat(account.owners()).hasSize(1);
    }

    @Test void cdslAndNps() {
        var result = Fixtures.parse(Fixtures.CDSL);
        assertThat(result.fileType()).isEqualTo(FileType.CDSL);
        assertThat(result.warnings()).isEmpty();
        assertThat(result.accounts().getFirst().boId()).isEqualTo("1200000000123456");
        assertThat(result.accounts().getFirst().clientId()).isEqualTo("00123456");
        assertThat(result.nps().pran()).isEqualTo("123456789012");
        assertThat(result.nps().schemes().getFirst().tier()).isEqualTo("I");
        assertThat(result.nps().schemes().getFirst().assetClass()).isEqualTo("E");
    }

    @Test void wrappedSecurityName() {
        var result = Fixtures.parse(Fixtures.NSDL.replace("Example Industries Limited", "Example Industries\nLimited"));
        assertThat(result.warnings()).isEmpty();
        assertThat(result.accounts().getFirst().holdings().getFirst().name()).isEqualTo("Example Industries Limited");
    }

    @Test void mixedDepositoriesKeepIssuerAndAccountTypeSeparate() {
        var result = Fixtures.parse(Fixtures.NSDL + "\nDP Name: CDSL Broker\nBO ID: 1200000000123456\nEquities\nINE002A01018 Other Shares 2 100.00 200.00\n");
        assertThat(result.fileType()).isEqualTo(FileType.NSDL);
        assertThat(result.accounts()).hasSize(2);
        assertThat(result.accounts().get(1).type()).isEqualTo(FileType.CDSL);
    }

    @Test void unknownColumnsNeverBecomeInventedHoldings() {
        var result = Fixtures.parse(Fixtures.NSDL.replace("10 2,000.00 20,000.00", "10 2,000.00 20,000.00 500.00 10.00"));
        assertThat(result.warnings()).extracting(Diagnostic::code).contains("UNPARSED_HOLDING", "ACCOUNT_VALUE_MISMATCH");
        assertThat(result.accounts().getFirst().holdings()).hasSize(2);
    }

    @Test void holdingArithmeticIsChecked() {
        var result = Fixtures.parse(Fixtures.NSDL.replace("10 2,000.00 20,000.00", "10 2,000.00 25,000.00"));
        assertThat(result.warnings()).extracting(Diagnostic::code).contains("HOLDING_VALUE_MISMATCH", "ACCOUNT_VALUE_MISMATCH");
    }

    @Test void transactionsAreNotSilentlyReportedAsHoldings() {
        var result = Fixtures.parse(Fixtures.NSDL + "\nTransaction Details\nINE002A01018 Example Industries 10 100.00 1000.00\n");
        assertThat(result.accounts().getFirst().holdings()).hasSize(3);
        assertThat(result.warnings()).extracting(Diagnostic::code).contains("DEMAT_TRANSACTIONS_NOT_PARSED");
    }
}
