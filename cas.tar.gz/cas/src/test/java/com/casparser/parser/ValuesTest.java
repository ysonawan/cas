package com.casparser.parser;

import static org.assertj.core.api.Assertions.*;
import java.time.LocalDate;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.jupiter.api.Test;

class ValuesTest {
    @ParameterizedTest
    @CsvSource(delimiter = '|', textBlock = """
            1,23,456.789|123456.789
            123,456.789|123456.789
            (1,000.123)|-1000.123
            -100.00|-100.00
            100.00-| -100.00
            100.00 DR|-100.00
            100.00 CR|100.00
            ₹ 42.12|42.12
            Rs. 42.12|42.12
            0.00000001|0.00000001
            """)
    void exactDecimal(String input, String expected) {
        assertThat(Values.decimal(input)).isEqualByComparingTo(expected.strip());
    }

    @ParameterizedTest @ValueSource(strings = {"-", "--", "N/A", "NIL", " "})
    void missingIsNotZero(String input) { assertThat(Values.decimal(input)).isNull(); }

    @ParameterizedTest @ValueSource(strings = {"NaN", "1.2.3", "1,2", "Infinity", "1e10", "abc"})
    void rejectsMalformedNumbers(String input) { assertThatThrownBy(() -> Values.decimal(input)).isInstanceOf(IllegalArgumentException.class); }

    @ParameterizedTest @ValueSource(strings = {"01-Apr-2024", "1-April-2024", "01/04/2024", "2024-04-01", "1 apr 2024"})
    void datesAreLocaleIndependent(String input) { assertThat(Values.date(input)).isEqualTo(LocalDate.of(2024, 4, 1)); }

    @ParameterizedTest @ValueSource(strings = {"31-Feb-2024", "29-Feb-2023", "31/04/2024", "01-13-2024"})
    void invalidDatesDoNotRollOver(String input) { assertThatThrownBy(() -> Values.date(input)).isInstanceOf(IllegalArgumentException.class); }

    @Test void numericTailPreservesMissingColumnsAndDescriptionNumbers() {
        var result = NumericTail.read("SIP instalment 1/12 100.00 1.00 - 20.00", 4);
        assertThat(result.prefix()).isEqualTo("SIP instalment 1/12");
        assertThat(result.values()).hasSize(4);
        assertThat(result.values().get(2)).isNull();
    }
}
