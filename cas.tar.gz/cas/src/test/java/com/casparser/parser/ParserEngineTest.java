package com.casparser.parser;

import static org.assertj.core.api.Assertions.*;
import com.casparser.domain.ParseException;
import com.casparser.domain.Statement;
import java.util.List;
import java.util.concurrent.Executors;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class ParserEngineTest {
    @ParameterizedTest @ValueSource(strings = {"Random document", "CAMS bank statement", "Consolidated Account Statement Unknown Issuer", "NSDL\nUnrelated report"})
    void refusesUnknownDocuments(String text) {
        assertThatThrownBy(() -> Fixtures.parse(text)).isInstanceOfSatisfying(ParseException.class,
                ex -> assertThat(ex.code()).isEqualTo("UNSUPPORTED_STATEMENT"));
    }

    @Test void refusesEmptyResults() {
        assertThatThrownBy(() -> Fixtures.parse("CAMS\nConsolidated Account Statement Summary\nAs on 31-Mar-2025\nInvestor: SAMPLE"))
                .isInstanceOfSatisfying(ParseException.class, ex -> assertThat(ex.code()).isEqualTo("NO_DATA"));
    }

    @Test void noCrossRequestStateUnderConcurrency() throws Exception {
        var engine = Fixtures.engine();
        try (var executor = Executors.newFixedThreadPool(8)) {
            var tasks = java.util.stream.IntStream.range(0, 40).mapToObj(i -> (java.util.concurrent.Callable<Statement>) () ->
                    engine.parse(SourceDocument.fromText(Fixtures.DETAILED.replace("12345678 / 90", "000" + i)), false, new ParseContext(30000, 100))).toList();
            var results = executor.invokeAll(tasks);
            for (int i = 0; i < results.size(); i++) assertThat(results.get(i).get().folios().getFirst().folio()).isEqualTo("000" + i);
        }
    }

    @Test void diagnosticsAreBounded() {
        var context = new ParseContext(30000, 1);
        context.warn("A", "A", "a", null);
        assertThatThrownBy(() -> context.warn("B", "B", "b", null)).isInstanceOfSatisfying(ParseException.class,
                e -> assertThat(e.code()).isEqualTo("TOO_MANY_DIAGNOSTICS"));
    }

    @Test void duplicateAdaptersAreConfigurationErrors() {
        var engine = new ParserEngine(new StatementDetector(), List.of(new MutualFundDetailedParser(), new MutualFundDetailedParser()));
        assertThatThrownBy(() -> engine.parse(SourceDocument.fromText(Fixtures.DETAILED), false, new ParseContext(30000, 100)))
                .isInstanceOfSatisfying(ParseException.class, ex -> assertThat(ex.code()).isEqualTo("PARSER_CONFIGURATION"));
    }

    @Test void deadlineEnforced() {
        assertThatThrownBy(() -> Fixtures.engine().parse(SourceDocument.fromText(Fixtures.DETAILED), false, new ParseContext(-1, 100)))
                .isInstanceOfSatisfying(ParseException.class, ex -> assertThat(ex.code()).isEqualTo("PARSE_TIMEOUT"));
    }
}
