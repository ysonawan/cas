package com.casparser.api;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.encryption.AccessPermission;
import org.apache.pdfbox.pdmodel.encryption.StandardProtectionPolicy;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

public final class PdfFixtures {
    private PdfFixtures() {}
    public static byte[] pdf(String text, String password) throws IOException {
        try (PDDocument document = new PDDocument(); var output = new ByteArrayOutputStream()) {
            for (String pageText : text.split("\f", -1)) {
                PDPage page = new PDPage();
                document.addPage(page);
                try (var stream = new PDPageContentStream(document, page)) {
                    stream.beginText();
                    stream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 8);
                    stream.setLeading(12);
                    stream.newLineAtOffset(30, 750);
                    for (String line : pageText.split("\\R")) {
                        stream.showText(line.replace('\t', ' '));
                        stream.newLine();
                    }
                    stream.endText();
                }
            }
            if (password != null) {
                var policy = new StandardProtectionPolicy("fixture-owner-phrase", password, new AccessPermission());
                policy.setEncryptionKeyLength(256);
                document.protect(policy);
            }
            document.save(output);
            return output.toByteArray();
        }
    }
}
