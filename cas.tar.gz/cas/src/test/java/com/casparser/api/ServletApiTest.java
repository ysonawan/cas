package com.casparser.api;

import static org.assertj.core.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.casparser.parser.Fixtures;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import tools.jackson.databind.json.JsonMapper;

/** Runs the real Spring controllers, filters, PDF extractor and parser without binding a socket. */
@SpringBootTest(properties = {"cas.api-key=fixture-key-with-at-least-32-characters", "cas.require-api-key=true",
        "spring.servlet.multipart.max-file-size=64KB", "spring.servlet.multipart.max-request-size=70KB"})
class ServletApiTest {
    private static final String KEY = "fixture-key-with-at-least-32-characters";
    @Autowired WebApplicationContext context;
    @Autowired RequestFilter filter;
    @Autowired JsonMapper json;
    MockMvc mvc;
    @BeforeEach void setUp() { mvc = MockMvcBuilders.webAppContextSetup(context).addFilters(filter).build(); }

    @ParameterizedTest @ValueSource(strings = {"plain", "encrypted"})
    void realPdfToJson(String kind) throws Exception {
        String pass = kind.equals("encrypted") ? "fixture-pass" : "";
        byte[] pdf = PdfFixtures.pdf(Fixtures.DETAILED, pass.isEmpty() ? null : pass);
        String response = mvc.perform(multipart("/api/v1/statements/parse")
                        .file(file(pdf)).param("password", pass).header("X-API-Key", KEY))
                .andExpect(status().isOk()).andExpect(header().string("Cache-Control", "no-store"))
                .andExpect(header().exists("X-Request-ID")).andReturn().getResponse().getContentAsString();
        var result = json.readTree(response);
        assertThat(result.path("status").asString()).isEqualTo("COMPLETE");
        var scheme = result.path("folios").get(0).path("schemes").get(0);
        assertThat(scheme.path("close").isString()).isTrue();
        assertThat(scheme.path("close").asString()).isEqualTo("15.000");
        assertThat(scheme.path("transactions").size()).isEqualTo(3);
        assertThat(response).doesNotContain("fixture-pass");
    }

    @Test void emptyFile() throws Exception { problem(new byte[0], null, 400, "EMPTY_FILE"); }
    @Test void nonPdf() throws Exception { problem("invalid pdf".getBytes(java.nio.charset.StandardCharsets.UTF_8), null, 415, "INVALID_FILE_TYPE"); }
    @Test void corruptPdf() throws Exception { problem("%PDF-1.7\ninvalid".getBytes(java.nio.charset.StandardCharsets.UTF_8), null, 422, "INVALID_PDF"); }
    @Test void missingTextLayer() throws Exception { problem(PdfFixtures.pdf("", null), null, 422, "NO_EXTRACTABLE_TEXT"); }
    @Test void wrongPassword() throws Exception { problem(PdfFixtures.pdf(Fixtures.DETAILED, "real-pass"), "bad-pass", 422, "INVALID_PDF_PASSWORD"); }
    @Test void tooLarge() throws Exception { problem(new byte[80_000], null, 413, "FILE_TOO_LARGE"); }

    @Test void noApiKey() throws Exception {
        var response = mvc.perform(multipart("/api/v1/statements/parse").file(file(new byte[]{1})))
                .andExpect(status().isUnauthorized()).andReturn().getResponse();
        assertThat(json.readTree(response.getContentAsString()).path("code").asString()).isEqualTo("UNAUTHORIZED");
    }

    @Test void queryParametersRejected() throws Exception {
        mvc.perform(multipart("/api/v1/statements/parse?password=example").file(file(new byte[]{1})).header("X-API-Key", KEY))
                .andExpect(status().isBadRequest());
    }

    @Test void strictModeRejectsWarnings() throws Exception {
        var pdf = PdfFixtures.pdf(Fixtures.DETAILED.replace("15.000\nNAV", "99.000\nNAV"), null);
        var response = mvc.perform(multipart("/api/v1/statements/parse").file(file(pdf)).param("strict", "true").header("X-API-Key", KEY))
                .andExpect(status().isUnprocessableContent()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(response).path("code").asString()).isEqualTo("STRICT_VALIDATION_FAILED");
    }

    @Test void missingPartAndInvalidOptionAre400() throws Exception {
        mvc.perform(multipart("/api/v1/statements/parse").header("X-API-Key", KEY)).andExpect(status().isBadRequest());
        mvc.perform(multipart("/api/v1/statements/parse").file(file(new byte[]{1})).param("strict", "maybe").header("X-API-Key", KEY))
                .andExpect(status().isBadRequest());
    }

    @Test void allIssuerFixturesThroughPdfExtraction() throws Exception {
        for (String text : new String[]{Fixtures.SUMMARY, Fixtures.NSDL, Fixtures.CDSL}) {
            mvc.perform(multipart("/api/v1/statements/parse").file(file(PdfFixtures.pdf(text, null))).header("X-API-Key", KEY))
                    .andExpect(status().isOk());
        }
    }

    @Test void healthAndUiAvailable() throws Exception {
        mvc.perform(get("/actuator/health")).andExpect(status().isOk());
        mvc.perform(get("/index.html")).andExpect(status().isOk());
    }

    private void problem(byte[] pdf, String pass, int expectedStatus, String code) throws Exception {
        var response = mvc.perform(multipart("/api/v1/statements/parse").file(file(pdf))
                        .param("password", pass == null ? "" : pass).header("X-API-Key", KEY))
                .andExpect(status().is(expectedStatus)).andReturn().getResponse();
        assertThat(response.getContentType()).contains("application/problem+json");
        assertThat(json.readTree(response.getContentAsString()).path("code").asString()).isEqualTo(code);
        assertThat(json.readTree(response.getContentAsString()).path("request_id").asString()).isNotBlank();
    }

    private MockMultipartFile file(byte[] bytes) { return new MockMultipartFile("file", "statement.pdf", "application/pdf", bytes); }
}
