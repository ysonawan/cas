package com.casparser.api;

import static org.assertj.core.api.Assertions.*;
import com.casparser.parser.Fixtures;
import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import tools.jackson.databind.json.JsonMapper;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {
        "cas.api-key=test-api-key-at-least-thirty-two-characters", "cas.require-api-key=true",
        "spring.servlet.multipart.max-file-size=64KB", "spring.servlet.multipart.max-request-size=70KB"})
@EnabledIfSystemProperty(named = "cas.http", matches = "true")
class HttpApiTest {
    private static final String KEY = "test-api-key-at-least-thirty-two-characters";
    @Value("${local.server.port}") int port;
    private final HttpClient http = HttpClient.newHttpClient();
    private final JsonMapper json = JsonMapper.builder().build();

    @ParameterizedTest @ValueSource(strings = {"plain", "encrypted"})
    void uploadReturnsExactJson(String variant) throws Exception {
        String password = variant.equals("encrypted") ? "fixture-pass" : null;
        var response = upload(PdfFixtures.pdf(Fixtures.DETAILED, password), password, false, KEY, "");
        assertThat(response.statusCode()).as(response.body()).isEqualTo(200);
        var root = json.readTree(response.body());
        assertThat(root.path("status").asString()).isEqualTo("COMPLETE");
        assertThat(root.path("folios").get(0).path("schemes").get(0).path("close").asString()).isEqualTo("15.000");
        assertThat(root.path("folios").get(0).path("schemes").get(0).path("close").isString()).isTrue();
        assertThat(root.path("statement_period").path("from").asString()).isEqualTo("2024-04-01");
        assertThat(response.headers().firstValue("Cache-Control")).contains("no-store");
        assertThat(response.headers().firstValue("X-Request-ID")).isPresent();
        assertThat(response.body()).doesNotContain("fixture-pass", "filename");
    }

    @Test void wrongPasswordIsStructuredAndDoesNotLeak() throws Exception {
        var response = upload(PdfFixtures.pdf(Fixtures.DETAILED, "correct-pass"), "wrong-pass", false, KEY, "");
        assertProblem(response, 422, "INVALID_PDF_PASSWORD");
        assertThat(response.body()).doesNotContain("wrong-pass", "correct-pass");
    }

    @Test void emptyFile() throws Exception { assertProblem(upload(new byte[0], null, false, KEY, ""), 400, "EMPTY_FILE"); }
    @Test void forgedPdfExtension() throws Exception { assertProblem(upload("not a pdf".getBytes(StandardCharsets.UTF_8), null, false, KEY, ""), 415, "INVALID_FILE_TYPE"); }
    @Test void corruptPdf() throws Exception { assertProblem(upload("%PDF-1.7\ncorrupt".getBytes(StandardCharsets.UTF_8), null, false, KEY, ""), 422, "INVALID_PDF"); }
    @Test void imageOnlyPdf() throws Exception { assertProblem(upload(PdfFixtures.pdf("", null), null, false, KEY, ""), 422, "NO_EXTRACTABLE_TEXT"); }
    @Test void authRequired() throws Exception { assertProblem(upload(new byte[]{1}, null, false, null, ""), 401, "UNAUTHORIZED"); }
    @Test void optionsNeverInQuery() throws Exception { assertProblem(upload(new byte[]{1}, null, false, KEY, "?password=example"), 400, "QUERY_PARAMETERS_NOT_ALLOWED"); }
    @Test void oversizedUpload() throws Exception { assertProblem(upload(new byte[80_000], null, false, KEY, ""), 413, "FILE_TOO_LARGE"); }

    @Test void strictReconciliation() throws Exception {
        var response = upload(PdfFixtures.pdf(Fixtures.DETAILED.replace("15.000\nNAV", "99.000\nNAV"), null), null, true, KEY, "");
        assertProblem(response, 422, "STRICT_VALIDATION_FAILED");
        assertThat(json.readTree(response.body()).path("warnings").size()).isGreaterThan(0);
    }

    @Test void unsupportedDocument() throws Exception {
        assertProblem(upload(PdfFixtures.pdf("This is a random text document with enough selectable text.", null), null, false, KEY, ""), 422, "UNSUPPORTED_STATEMENT");
    }

    @Test void healthIsPublicAndMinimal() throws Exception {
        var response = http.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + "/actuator/health")).GET().build(), HttpResponse.BodyHandlers.ofString());
        assertThat(response.statusCode()).isEqualTo(200);
        assertThat(json.readTree(response.body()).path("status").asString()).isEqualTo("UP");
        assertThat(response.body()).doesNotContain("diskSpace");
    }

    private HttpResponse<String> upload(byte[] pdf, String password, boolean strict, String key, String query) throws Exception {
        String boundary = "cas-test-" + UUID.randomUUID();
        var body = new ByteArrayOutputStream();
        body.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"statement.pdf\"\r\nContent-Type: application/pdf\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        body.write(pdf);
        if (password != null) body.write(("\r\n--" + boundary + "\r\nContent-Disposition: form-data; name=\"password\"\r\n\r\n" + password).getBytes(StandardCharsets.UTF_8));
        body.write(("\r\n--" + boundary + "\r\nContent-Disposition: form-data; name=\"strict\"\r\n\r\n" + strict + "\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
        var request = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + "/api/v1/statements/parse" + query))
                .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                .POST(HttpRequest.BodyPublishers.ofByteArray(body.toByteArray()));
        if (key != null) request.header("X-API-Key", key);
        return http.send(request.build(), HttpResponse.BodyHandlers.ofString());
    }

    private void assertProblem(HttpResponse<String> response, int status, String code) throws Exception {
        assertThat(response.statusCode()).as(response.body()).isEqualTo(status);
        assertThat(json.readTree(response.body()).path("code").asString()).isEqualTo(code);
        assertThat(response.headers().firstValue("Content-Type").orElse("")).contains("application/problem+json");
        assertThat(json.readTree(response.body()).path("request_id").asString()).isNotBlank();
    }
}
