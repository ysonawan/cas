package com.casparser.samples;

import com.casparser.config.ParserProperties;
import com.casparser.domain.ParseException;
import com.casparser.extract.PdfDocumentReader;
import com.casparser.parser.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import tools.jackson.databind.json.JsonMapper;

/** Opt-in local corpus audit. Never bundles private samples into the build. */
@EnabledIfSystemProperty(named = "cas.samples", matches = "true")
class SampleAuditTest {
    @Test void auditLocalCorpus() throws Exception {
        ((ch.qos.logback.classic.Logger) org.slf4j.LoggerFactory.getLogger("org.apache.pdfbox")).setLevel(ch.qos.logback.classic.Level.ERROR);
        var properties = new ParserProperties(1000, 10_000_000, 32000, 2, 120000, 10000);
        var reader = new PdfDocumentReader(properties);
        var engine = new ParserEngine(new StatementDetector(), List.of(new MutualFundDetailedParser(), new MutualFundSummaryParser(), new DematParser()));
        Files.createDirectories(Path.of("target/sample-audit"));
        List<Path> paths;
        paths = pdfFiles(Path.of("samples")).stream().sorted().toList();
        int index = 0;
        for (Path path : paths) {
            String id = String.format("sample-%02d", ++index);
            String filename = path.getFileName().toString();
            String pass = filename.substring(filename.lastIndexOf('_') + 1, filename.lastIndexOf('.'));
            try {
                if (Boolean.getBoolean("cas.fonts") && path.getParent().getFileName().toString().startsWith("cdsl")) {
                    try (var pdf = org.apache.pdfbox.Loader.loadPDF(Files.readAllBytes(path), pass)) {
                        var fonts = new java.util.TreeMap<String, StringBuilder>();
                        var stripper = new org.apache.pdfbox.text.PDFTextStripper() {
                            @Override protected void processTextPosition(org.apache.pdfbox.text.TextPosition position) {
                                var sample = fonts.computeIfAbsent(position.getFont().getName(), ignored -> new StringBuilder());
                                if (sample.length() < 130) sample.append(position.getUnicode());
                            }
                        };
                        stripper.setEndPage(1);
                        stripper.getText(pdf);
                        fonts.forEach((font, sample) -> System.out.println(font + " = " + sample));
                    }
                    break;
                }
                var context = new ParseContext(120000, 10000);
                var document = reader.read(Files.readAllBytes(path), pass, context);
                // Local diagnostic files are sensitive, ignored build artifacts. They are never API output.
                Files.writeString(Path.of("target/sample-audit/" + id + ".txt"), document.text());
                System.out.printf("%s family=%s pages=%d lines=%d ", id, path.getParent().getFileName(), document.pages(), document.lines().size());
                var result = engine.parse(document, false, context);
                System.out.printf("issuer=%s folios=%d holdings=%d transactions=%d warnings=%d%n", result.fileType(), result.folios().size(), result.metadata().parsedHoldings(), result.metadata().parsedTransactions(), result.warnings().size());
                var counts = result.warnings().stream().collect(java.util.stream.Collectors.groupingBy(w -> w.code(), java.util.TreeMap::new, java.util.stream.Collectors.counting()));
                System.out.println("  diagnostic_counts=" + counts);
                if (Boolean.getBoolean("cas.details")) {
                    for (String code : counts.keySet()) result.warnings().stream().filter(w -> code.equals(w.code())).limit(5).forEach(w -> {
                        document.lines().stream().filter(l -> l.location().equals(w.location())).findFirst()
                                .ifPresent(l -> System.out.println("  " + code + ": " + l.text()));
                        if (code.equals("UNKNOWN_ASSET_TYPE")) result.accounts().stream().flatMap(a -> a.holdings().stream())
                                .filter(h -> h.source().equals(w.location())).forEach(h -> System.out.println("    name=" + h.name()));
                    });
                }
                Files.writeString(Path.of("target/sample-audit/" + id + "-warnings.txt"), result.warnings().stream()
                        .map(w -> w.code() + " " + w.path() + " " + w.location()).collect(java.util.stream.Collectors.joining("\n")));
            } catch (ParseException ex) {
                System.out.printf("error=%s%n", ex.code());
            }
        }
    }

    private static List<Path> pdfFiles(Path directory) throws Exception {
        List<Path> result = new java.util.ArrayList<>();
        try (var entries = Files.newDirectoryStream(directory)) {
            for (Path entry : entries) {
                String name = entry.getFileName().toString().toLowerCase(Locale.ROOT);
                if (name.contains("password") || name.contains("secret") || name.contains("credential") || name.startsWith(".")) continue;
                if (Files.isDirectory(entry)) result.addAll(pdfFiles(entry));
                else if (name.endsWith(".pdf")) result.add(entry);
            }
        }
        return result;
    }
}
