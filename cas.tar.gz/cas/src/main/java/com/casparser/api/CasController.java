package com.casparser.api;

import com.casparser.domain.Statement;
import com.casparser.service.CasParsingService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class CasController {
    private final CasParsingService service;
    public CasController(CasParsingService service) { this.service = service; }

    @PostMapping(value = "/api/v1/statements/parse", consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Statement parse(@RequestPart("file") MultipartFile file,
                           @RequestParam(value = "password", required = false) String password,
                           @RequestParam(value = "strict", defaultValue = "false") boolean strict) {
        return service.parse(file, password, strict);
    }
}
