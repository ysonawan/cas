package com.casparser.api;

import com.casparser.domain.ParseException;
import jakarta.servlet.http.HttpServletRequest;
import java.net.URI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;

@RestControllerAdvice
public class ApiExceptionHandler {
    private static final Logger LOG = LoggerFactory.getLogger(ApiExceptionHandler.class);

    @ExceptionHandler(ParseException.class)
    ResponseEntity<ProblemDetail> parsing(ParseException exception, HttpServletRequest request) {
        ProblemDetail problem = problem(exception.status(), exception.code(), exception.getMessage(), request);
        if (!exception.diagnostics().isEmpty()) problem.setProperty("warnings", exception.diagnostics());
        var response = ResponseEntity.status(exception.status());
        if (exception.status() == 429) response.header("Retry-After", "2");
        return response.body(problem);
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    ProblemDetail tooLarge(MaxUploadSizeExceededException exception, HttpServletRequest request) {
        return problem(413, "FILE_TOO_LARGE", "The multipart upload exceeds the configured size limit.", request);
    }

    @ExceptionHandler(MultipartException.class)
    ProblemDetail multipart(MultipartException exception, HttpServletRequest request) {
        return problem(400, "INVALID_MULTIPART", "The multipart upload is malformed or incomplete.", request);
    }

    @ExceptionHandler(Exception.class)
    ProblemDetail unexpected(Exception exception, HttpServletRequest request) {
        if (exception instanceof org.springframework.web.method.annotation.MethodArgumentTypeMismatchException)
            return problem(400, "INVALID_REQUEST", "The request contains an invalid parameter value.", request);
        if (exception instanceof ErrorResponse error) {
            int status = error.getStatusCode().value();
            return problem(status, "INVALID_REQUEST", switch (status) {
                case 404 -> "The requested resource does not exist.";
                case 405 -> "The HTTP method is not supported for this resource.";
                case 415 -> "Use multipart/form-data with a file part named 'file'.";
                default -> "The request contains missing or invalid parameters.";
            }, request);
        }
        // Exception messages and stack traces may contain document text, filenames or request parameters.
        LOG.error("Unexpected API failure request_id={} exception_type={}", request.getAttribute("requestId"), exception.getClass().getSimpleName());
        return problem(500, "INTERNAL_ERROR", "The request could not be processed. Use the request ID when reporting this error.", request);
    }

    static ProblemDetail problem(int status, String code, String message, HttpServletRequest request) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatusCode.valueOf(status), message);
        problem.setType(URI.create("urn:cas-parser:error:" + code.toLowerCase(java.util.Locale.ROOT).replace('_', '-')));
        problem.setTitle(code);
        problem.setProperty("code", code);
        problem.setProperty("request_id", request.getAttribute("requestId"));
        return problem;
    }
}
