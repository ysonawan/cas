package com.casparser.api;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import tools.jackson.databind.json.JsonMapper;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public final class RequestFilter extends OncePerRequestFilter {
    private final byte[] apiKey;
    private final JsonMapper mapper;

    public RequestFilter(@Value("${cas.api-key:}") String apiKey,
                         @Value("${cas.require-api-key:false}") boolean requireApiKey, JsonMapper mapper) {
        if (requireApiKey && apiKey.length() < 32) throw new IllegalArgumentException("Production requires CAS_API_KEY with at least 32 characters");
        this.apiKey = apiKey.getBytes(StandardCharsets.UTF_8);
        this.mapper = mapper;
    }

    @Override protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                              FilterChain chain) throws ServletException, IOException {
        String requestId = UUID.randomUUID().toString();
        request.setAttribute("requestId", requestId);
        response.setHeader("X-Request-ID", requestId);
        response.setHeader("Cache-Control", "no-store");
        response.setHeader("X-Content-Type-Options", "nosniff");
        response.setHeader("Referrer-Policy", "no-referrer");
        response.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
        String query = request.getQueryString();
        if (query != null && request.getRequestURI().startsWith("/api/")) {
            // All options belong in the multipart body: URLs are routinely logged by proxies.
            fail(400, "QUERY_PARAMETERS_NOT_ALLOWED", "Send parse options in multipart form fields, not in the URL.", request, response);
            return;
        }
        if (apiKey.length > 0 && request.getRequestURI().startsWith("/api/")) {
            String supplied = request.getHeader("X-API-Key");
            if (supplied == null || supplied.length() > 1024 || !MessageDigest.isEqual(apiKey, supplied.getBytes(StandardCharsets.UTF_8))) {
                fail(401, "UNAUTHORIZED", "A valid X-API-Key header is required.", request, response);
                return;
            }
        }
        chain.doFilter(request, response);
    }

    private void fail(int status, String code, String detail, HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setStatus(status);
        response.setContentType("application/problem+json");
        mapper.writeValue(response.getOutputStream(), ApiExceptionHandler.problem(status, code, detail, request));
    }
}
