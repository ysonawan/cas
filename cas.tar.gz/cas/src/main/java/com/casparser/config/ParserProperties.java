package com.casparser.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("cas.parser")
public record ParserProperties(int maxPages, int maxCharacters, int maxLineCharacters,
                               int maxConcurrentParses, long timeoutMillis, int maxDiagnostics) {
    public ParserProperties {
        if (maxPages < 1 || maxPages > 2000 || maxCharacters < 1000 || maxCharacters > 20_000_000
                || maxLineCharacters < 256 || maxLineCharacters > 100_000
                || maxConcurrentParses < 1 || maxConcurrentParses > 32
                || timeoutMillis < 100 || timeoutMillis > 300_000 || maxDiagnostics < 1 || maxDiagnostics > 10_000)
            throw new IllegalArgumentException("CAS parser limits are outside the supported range");
    }
}
