package com.casparser.config;

import com.casparser.parser.*;
import java.util.List;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
public class ParserConfiguration {
    @Bean StatementDetector statementDetector() { return new StatementDetector(); }
    @Bean StatementParser mutualFundDetailedParser() { return new MutualFundDetailedParser(); }
    @Bean StatementParser mutualFundSummaryParser() { return new MutualFundSummaryParser(); }
    @Bean StatementParser dematParser() { return new DematParser(); }
    @Bean ParserEngine parserEngine(StatementDetector detector, List<StatementParser> parsers) {
        return new ParserEngine(detector, parsers);
    }
}
