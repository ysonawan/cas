package com.casparser.config;

import java.math.BigDecimal;
import org.springframework.boot.jackson.autoconfigure.JsonMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tools.jackson.core.JsonGenerator;
import tools.jackson.databind.PropertyNamingStrategies;
import tools.jackson.databind.SerializationContext;
import tools.jackson.databind.ValueSerializer;
import tools.jackson.databind.module.SimpleModule;

@Configuration(proxyBeanMethods = false)
public class JsonConfiguration {
    @Bean JsonMapperBuilderCustomizer exactDecimalJson() {
        SimpleModule module = new SimpleModule("exact-decimal-strings");
        module.addSerializer(BigDecimal.class, new ValueSerializer<>() {
            @Override public void serialize(BigDecimal value, JsonGenerator generator, SerializationContext context) {
                generator.writeString(value.toPlainString());
            }
        });
        return builder -> builder.propertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE).addModule(module);
    }
}
