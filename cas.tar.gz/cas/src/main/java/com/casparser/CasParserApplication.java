package com.casparser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class CasParserApplication {
    public static void main(String[] args) {
        SpringApplication.run(CasParserApplication.class, args);
    }
}
