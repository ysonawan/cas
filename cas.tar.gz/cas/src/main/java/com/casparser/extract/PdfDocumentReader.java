package com.casparser.extract;

import com.casparser.config.ParserProperties;
import com.casparser.domain.ParseException;
import com.casparser.domain.Statement.Location;
import com.casparser.parser.ParseContext;
import com.casparser.parser.SourceDocument;
import com.casparser.parser.SourceDocument.Line;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;
import org.springframework.stereotype.Component;

@Component
public final class PdfDocumentReader {
    private final ParserProperties properties;
    public PdfDocumentReader(ParserProperties properties) { this.properties = properties; }

    public SourceDocument read(byte[] bytes, String password, ParseContext context) {
        if (bytes.length < 8 || bytes[0] != '%' || bytes[1] != 'P' || bytes[2] != 'D' || bytes[3] != 'F' || bytes[4] != '-')
            throw new ParseException("INVALID_FILE_TYPE", 415, "Only original, text-based CAS PDF files are accepted.");
        try (PDDocument document = Loader.loadPDF(bytes, password == null ? "" : password)) {
            context.checkBudget();
            int pages = document.getNumberOfPages();
            if (pages == 0) throw new ParseException("EMPTY_PDF", 422, "The PDF has no pages.");
            if (pages > properties.maxPages()) throw new ParseException("PAGE_LIMIT_EXCEEDED", 413, "The PDF exceeds the configured page limit.");
            // Issuer CAS documents commonly disable viewer copy/paste. Loading with the
            // supplied opening password is sufficient for this user-requested import.
            LayoutStripper stripper = new LayoutStripper(properties, context);
            stripper.getText(document);
            if (stripper.lines.stream().mapToInt(l -> l.text().length()).sum() < 30)
                throw new ParseException("NO_EXTRACTABLE_TEXT", 422, "The PDF has no usable text layer. Scanned/image-only PDFs require OCR and are not supported.");
            var info = document.getDocumentInformation();
            return new SourceDocument(stripper.lines, pages, Map.of(
                    "producer", value(info.getProducer()), "creator", value(info.getCreator()), "title", value(info.getTitle())));
        } catch (InvalidPasswordException ex) {
            throw new ParseException("INVALID_PDF_PASSWORD", 422, "The PDF requires a password or the supplied password is incorrect.");
        } catch (IOException ex) {
            throw new ParseException("INVALID_PDF", 422, "The PDF is damaged, unreadable or uses an unsupported encryption method.");
        }
    }

    private static String value(String value) { return value == null ? "" : value; }

    /** Groups glyphs by baseline, retaining wide column gaps as tabs. */
    private static final class LayoutStripper extends PDFTextStripper {
        final List<Line> lines = new ArrayList<>();
        private final ParserProperties properties;
        private final ParseContext context;
        private int glyphs, characters;

        LayoutStripper(ParserProperties properties, ParseContext context) throws IOException {
            this.properties = properties;
            this.context = context;
            setSortByPosition(true);
            setSuppressDuplicateOverlappingText(true);
        }

        @Override protected void processTextPosition(TextPosition text) {
            if (++glyphs > properties.maxCharacters()) throw new ParseException("TEXT_LIMIT_EXCEEDED", 413, "The PDF exceeds the configured text limit.");
            if ((glyphs & 1023) == 0) context.checkBudget();
            // Diagonal watermarks do not belong to transaction tables.
            if (Math.abs(text.getDir()) < 1 || Math.abs(text.getDir() - 360) < 1) super.processTextPosition(text);
        }

        @Override protected void writePage() throws IOException {
            context.checkBudget();
            List<TextPosition> all = getCharactersByArticle().stream().flatMap(List::stream).toList();
            // Select the English layer in the known bilingual CDSL template, including
            // fonts nested in form XObjects (not just page-level font resources).
            boolean englishLayer = all.stream().anyMatch(p -> p.getFont().getName().toLowerCase(java.util.Locale.ROOT).contains("lato"));
            List<TextPosition> positions = all.stream()
                    .filter(p -> !englishLayer || !p.getFont().getName().toLowerCase(java.util.Locale.ROOT).contains("mangal"))
                    .sorted(Comparator.comparingDouble(TextPosition::getYDirAdj).thenComparingDouble(TextPosition::getXDirAdj)).toList();
            List<TextPosition> row = new ArrayList<>();
            float baseline = Float.NaN;
            int lineNumber = 0;
            for (TextPosition position : positions) {
                if (!row.isEmpty() && Math.abs(position.getYDirAdj() - baseline) > 2.2f) {
                    append(row, ++lineNumber); row.clear();
                }
                if (row.isEmpty()) baseline = position.getYDirAdj();
                row.add(position);
            }
            if (!row.isEmpty()) append(row, ++lineNumber);
            if (lineNumber == 0) context.warn("PAGE_WITHOUT_TEXT", "A page has no extractable text and may contain scanned data.", "document", new Location(getCurrentPageNo(), 1));
        }

        private void append(List<TextPosition> row, int lineNumber) {
            row.sort(Comparator.comparingDouble(TextPosition::getXDirAdj));
            StringBuilder text = new StringBuilder();
            StringBuilder cellText = new StringBuilder();
            List<SourceDocument.Cell> cells = new ArrayList<>();
            float cellX = row.getFirst().getXDirAdj(), cellY = row.getFirst().getYDirAdj();
            float right = Float.NaN;
            for (TextPosition position : row) {
                float space = Math.max(position.getWidthOfSpace(), 2f);
                if (!Float.isNaN(right)) {
                    float gap = position.getXDirAdj() - right;
                    if (gap > space * 1.8f) {
                        text.append('\t');
                        cells.add(new SourceDocument.Cell(cellText.toString().strip(), cellX, cellY, right));
                        cellText.setLength(0); cellX = position.getXDirAdj(); cellY = position.getYDirAdj();
                    } else if (gap > space * 0.35f && !text.isEmpty() && !Character.isWhitespace(text.charAt(text.length() - 1))) {
                        text.append(' '); cellText.append(' ');
                    }
                }
                text.append(position.getUnicode());
                cellText.append(position.getUnicode());
                right = position.getXDirAdj() + position.getWidthDirAdj();
                if (text.length() > properties.maxLineCharacters()) throw new ParseException("LINE_LIMIT_EXCEEDED", 413, "A PDF text row exceeds the configured length limit.");
            }
            cells.add(new SourceDocument.Cell(cellText.toString().strip(), cellX, cellY, right));
            characters += text.length();
            if (characters > properties.maxCharacters()) throw new ParseException("TEXT_LIMIT_EXCEEDED", 413, "The PDF exceeds the configured text limit.");
            Line line = new Line(text.toString(), new Location(getCurrentPageNo(), lineNumber), cells);
            if (!line.text().isBlank()) lines.add(line);
        }
    }
}
