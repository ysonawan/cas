package com.casparser.service;

import com.casparser.config.ParserProperties;
import com.casparser.domain.ParseException;
import com.casparser.domain.Statement;
import com.casparser.extract.PdfDocumentReader;
import com.casparser.parser.ParseContext;
import com.casparser.parser.ParserEngine;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.Semaphore;
import org.springframework.boot.servlet.autoconfigure.MultipartProperties;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public final class CasParsingService {
    private final PdfDocumentReader reader;
    private final ParserEngine engine;
    private final ParserProperties properties;
    private final Semaphore permits;
    private final MeterRegistry metrics;
    private final int maxBytes;

    public CasParsingService(PdfDocumentReader reader, ParserEngine engine, ParserProperties properties,
                             MultipartProperties multipart, MeterRegistry metrics) {
        this.reader = reader; this.engine = engine; this.properties = properties; this.metrics = metrics;
        this.permits = new Semaphore(properties.maxConcurrentParses());
        long configured = multipart.getMaxFileSize().toBytes();
        if (configured < 1 || configured > 100 * 1024 * 1024L) throw new IllegalArgumentException("Upload size must be between one byte and 100 MiB");
        this.maxBytes = Math.toIntExact(configured);
    }

    public Statement parse(MultipartFile file, String password, boolean strict) {
        if (file.isEmpty()) throw new ParseException("EMPTY_FILE", 400, "The uploaded file is empty.");
        if (file.getSize() > maxBytes) throw new ParseException("FILE_TOO_LARGE", 413, "The file exceeds the configured upload limit.");
        if (password != null && password.length() > 256) throw new ParseException("INVALID_REQUEST", 400, "PDF password must not exceed 256 characters.");
        if (!permits.tryAcquire()) throw new ParseException("PARSER_BUSY", 429, "All parser slots are occupied. Retry shortly.");
        byte[] bytes = null;
        Timer.Sample timer = Timer.start(metrics);
        String outcome = "error";
        try (var input = file.getInputStream()) {
            bytes = input.readNBytes(maxBytes + 1);
            if (bytes.length > maxBytes) throw new ParseException("FILE_TOO_LARGE", 413, "The file exceeds the configured upload limit.");
            ParseContext context = new ParseContext(properties.timeoutMillis(), properties.maxDiagnostics());
            Statement result = engine.parse(reader.read(bytes, password, context), strict, context);
            outcome = result.status().name().toLowerCase(java.util.Locale.ROOT);
            return result;
        } catch (IOException ex) {
            throw new ParseException("UPLOAD_READ_FAILED", 400, "The uploaded file could not be read.");
        } finally {
            if (bytes != null) Arrays.fill(bytes, (byte) 0);
            permits.release();
            timer.stop(Timer.builder("cas.parse.duration").tag("outcome", outcome).register(metrics));
        }
    }
}
