package com.casparser.domain;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/** Immutable public contract. Missing values are null, never invented zeros. */
public record Statement(
        String schemaVersion, FileType fileType, CasType casType, ParseStatus status,
        Period statementPeriod, Investor investorInfo, List<Folio> folios,
        List<DematAccount> accounts, Nps nps, List<Diagnostic> warnings, Metadata metadata) {

    public Statement {
        folios = List.copyOf(folios);
        accounts = List.copyOf(accounts);
        warnings = List.copyOf(warnings);
    }

    public enum FileType { CAMS, KFINTECH, NSDL, CDSL }
    public enum CasType { DETAILED, SUMMARY, DEMAT }
    public enum ParseStatus { COMPLETE, PARTIAL }
    public enum Severity { WARNING, ERROR }
    public enum AssetType { EQUITY, MUTUAL_FUND, BOND, ETF, REIT, INVIT, OTHER }
    public enum TransactionType {
        PURCHASE, PURCHASE_SIP, REDEMPTION, SWITCH_IN, SWITCH_OUT,
        SWITCH_IN_MERGER, SWITCH_OUT_MERGER, DIVIDEND_PAYOUT, DIVIDEND_REINVEST,
        STT_TAX, STAMP_DUTY_TAX, TDS_TAX, SEGREGATION, GIFT_IN, GIFT_OUT,
        REVERSAL, BONUS, TRANSMISSION_IN, TRANSMISSION_OUT, TRANSFER_IN, TRANSFER_OUT, FEE, MISC, UNKNOWN
    }

    public record Period(LocalDate from, LocalDate to) {}
    public record Investor(String name, String email, String address, String mobile, String pan) {}
    public record Location(int page, int line) {}
    public record Diagnostic(String code, Severity severity, String message, String path, Location location) {}
    public record Metadata(String parserVersion, int pages, int parsedTransactions, int parsedHoldings) {}
    public record Folio(String folio, String amc, String name, String pan, String kyc,
                        String panKyc, List<Scheme> schemes) {
        public Folio { schemes = List.copyOf(schemes); }
    }
    public record Scheme(String scheme, String advisor, String rtaCode, String rta,
                         String isin, String amfi, List<String> nominees, BigDecimal open,
                         BigDecimal close, BigDecimal closeCalculated, Valuation valuation,
                         List<Transaction> transactions, Location source) {
        public Scheme {
            nominees = List.copyOf(nominees);
            transactions = List.copyOf(transactions);
        }
    }
    public record Valuation(LocalDate date, BigDecimal nav, BigDecimal cost, BigDecimal value) {}
    public record Transaction(LocalDate date, String description, BigDecimal amount,
                              BigDecimal units, BigDecimal nav, BigDecimal balance,
                              TransactionType type, BigDecimal dividendRate,
                              String giftFolio, Location source) {}
    public record Owner(String name, String pan) {}
    public record DematAccount(String name, FileType type, String dpId, String clientId,
                               String boId, BigDecimal balance, List<Owner> owners,
                               List<Holding> holdings, List<SecurityTransaction> transactions,
                               List<SecurityBalance> securityBalances, Location source) {
        public DematAccount(String name, FileType type, String dpId, String clientId, String boId, BigDecimal balance,
                            List<Owner> owners, List<Holding> holdings, Location source) {
            this(name, type, dpId, clientId, boId, balance, owners, holdings, List.of(), List.of(), source);
        }
        public DematAccount {
            owners = List.copyOf(owners);
            holdings = List.copyOf(holdings);
            transactions = List.copyOf(transactions);
            securityBalances = List.copyOf(securityBalances);
        }
    }
    public record SecurityTransaction(LocalDate date, String isin, String folio, String description,
                                       BigDecimal credit, BigDecimal debit, BigDecimal units, BigDecimal amount,
                                       BigDecimal nav, BigDecimal price, BigDecimal balance, BigDecimal stampDuty,
                                       TransactionType type, Location source) {}
    public record SecurityBalance(String isin, String folio, BigDecimal open, BigDecimal close, BigDecimal closeCalculated) {}
    public record Holding(String isin, String name, AssetType assetType, String folio,
                          BigDecimal units, BigDecimal price, BigDecimal value,
                          BigDecimal cost, BigDecimal faceValue, BigDecimal couponRate,
                          LocalDate maturityDate, Location source, Map<String, BigDecimal> balances,
                          BigDecimal averageCost, BigDecimal unrealizedGain, BigDecimal annualizedReturn, String ucc) {
        public Holding(String isin, String name, AssetType assetType, String folio, BigDecimal units, BigDecimal price,
                       BigDecimal value, BigDecimal cost, BigDecimal faceValue, BigDecimal couponRate, LocalDate maturityDate, Location source) {
            this(isin, name, assetType, folio, units, price, value, cost, faceValue, couponRate, maturityDate, source, Map.of(), null, null, null, null);
        }
        public Holding { balances = java.util.Collections.unmodifiableMap(new java.util.LinkedHashMap<>(balances)); }
    }
    public record Nps(String pran, String provider, BigDecimal value, List<NpsScheme> schemes, List<NpsTransaction> transactions) {
        public Nps(String pran, String provider, BigDecimal value, List<NpsScheme> schemes) { this(pran, provider, value, schemes, List.of()); }
        public Nps { schemes = List.copyOf(schemes); transactions = List.copyOf(transactions); }
    }
    public record NpsTransaction(LocalDate date, String scheme, String description, BigDecimal amount, BigDecimal nav,
                                 BigDecimal units, String direction, Location source) {}
    public record NpsScheme(String scheme, String fundManager, String tier, String assetClass,
                            BigDecimal units, BigDecimal nav, BigDecimal value, Location source) {}
}
