package com.casparser.domain;

import java.util.List;
import com.casparser.domain.Statement.Diagnostic;

/** Messages are safe for API clients; never embed document content or supplied passwords. */
public final class ParseException extends RuntimeException {
    private final String code;
    private final int status;
    private final List<Diagnostic> diagnostics;

    public ParseException(String code, int status, String message) {
        this(code, status, message, List.of());
    }

    public ParseException(String code, int status, String message, List<Diagnostic> diagnostics) {
        super(message);
        this.code = code;
        this.status = status;
        this.diagnostics = List.copyOf(diagnostics);
    }

    public String code() { return code; }
    public int status() { return status; }
    public List<Diagnostic> diagnostics() { return diagnostics; }
}
