package com.casparser.parser;

import com.casparser.domain.Statement.Location;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public record SourceDocument(List<Line> lines, int pages, Map<String, String> metadata) {
    public SourceDocument {
        lines = List.copyOf(lines);
        metadata = Map.copyOf(metadata);
    }

    public String text() {
        return String.join("\n", lines.stream().map(Line::text).toList());
    }

    public record Cell(String text, float x, float y, float right) {}
    public record Line(String text, Location location, List<Cell> cells) {
        public Line(String text, Location location) { this(text, location, List.of()); }
        public Line {
            cells = List.copyOf(cells);
            text = Normalizer.normalize(text, Normalizer.Form.NFKC)
                    .replace('\u00a0', ' ').replace('\u2212', '-')
                    .replace('\u2013', '-').replace('\u2014', '-').strip();
        }
        public String flat() { return text.replaceAll("\\s+", " ").strip(); }
    }

    /** Also useful to test parser rules without depending on PDF layout extraction. */
    public static SourceDocument fromText(String text) {
        List<Line> lines = new ArrayList<>();
        String[] pages = text.split("\f", -1);
        for (int p = 0; p < pages.length; p++) {
            String[] rows = pages[p].split("\\R", -1);
            for (int n = 0; n < rows.length; n++) {
                Line line = new Line(rows[n], new Location(p + 1, n + 1));
                if (!line.text().isBlank()) lines.add(line);
            }
        }
        return new SourceDocument(lines, pages.length, Map.of());
    }
}
