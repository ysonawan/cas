package com.casparser.parser;

import com.casparser.domain.ParseException;
import com.casparser.domain.Statement.*;
import java.util.ArrayList;
import java.util.List;

/** Per-request mutable diagnostics; parser singletons never retain document state. */
public final class ParseContext {
    private final List<Diagnostic> warnings = new ArrayList<>();
    private final long deadline;
    private final int maxDiagnostics;

    public ParseContext(long timeoutMillis, int maxDiagnostics) {
        this.deadline = System.nanoTime() + timeoutMillis * 1_000_000L;
        this.maxDiagnostics = maxDiagnostics;
    }

    public void checkBudget() {
        if (Thread.currentThread().isInterrupted() || System.nanoTime() > deadline)
            throw new ParseException("PARSE_TIMEOUT", 422, "The statement exceeded the parsing time budget.");
    }

    public void warn(String code, String message, String path, Location location) {
        if (warnings.size() >= maxDiagnostics)
            throw new ParseException("TOO_MANY_DIAGNOSTICS", 422, "Too many unrecognized or inconsistent rows.");
        warnings.add(new Diagnostic(code, Severity.WARNING, message, path, location));
    }

    public List<Diagnostic> warnings() { return List.copyOf(warnings); }
}
