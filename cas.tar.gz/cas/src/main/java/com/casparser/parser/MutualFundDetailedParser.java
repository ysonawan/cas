package com.casparser.parser;

import com.casparser.domain.Statement;
import com.casparser.domain.Statement.*;
import com.casparser.parser.SourceDocument.Line;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.regex.Pattern;

public final class MutualFundDetailedParser implements StatementParser {
    private static final Pattern TRANSACTION = Pattern.compile("^(" + Values.DATE + ")\\s+(.+)$");
    private final TransactionClassifier classifier = new TransactionClassifier();

    @Override public boolean supports(FileType type, CasType casType) {
        return (type == FileType.CAMS || type == FileType.KFINTECH) && casType == CasType.DETAILED;
    }

    @Override public Statement parse(SourceDocument document, Detection detection, ParseContext context) {
        var period = CommonSections.period(document, context);
        var investor = CommonSections.investor(document, context);
        MutualFundState state = new MutualFundState();
        Line pending = null;
        boolean notes = false;
        for (Line line : document.lines()) {
            context.checkBudget();
            String text = line.flat();
            if (CommonSections.noise(text)) continue;
            boolean transaction = TRANSACTION.matcher(text).matches();
            boolean boundary = transaction || text.matches("(?i)^(?:Folio|Scheme|PAN|KYC|Opening|Closing|NAV|Market Value|Valuation|Nominee|Total Cost|Cost of|Registrar|AMFI|ISIN).*" )
                    || text.matches("(?i).*Mutual Fund$") || text.matches("(?i)^[A-Z0-9]{2,20}\\s*-.*(?:Fund|Plan|Growth|IDCW).*" );
            if (pending != null && boundary) {
                transaction(pending, state, context);
                pending = null;
            }
            if (transaction) {
                pending = line;
                notes = false;
                if (NumericTail.read(TRANSACTION.matcher(text).replaceFirst("$2"), 4).values().size() == 4
                        || TransactionClassifier.tax(classifier.classify(text.replaceFirst("^" + Values.DATE + "\\s+", ""), null))) {
                    transaction(pending, state, context); pending = null;
                }
                continue;
            }
            if (MutualFundSections.structural(line, state, context)) {
                if (text.matches("(?i)^Closing.*")) notes = true;
                else if (text.matches("(?i)^(?:Folio|Scheme|Opening).*")) notes = false;
                continue;
            }
            if (notes) continue;
            if (pending != null) {
                String joined = pending.text() + " " + text;
                if (joined.length() > 16_384) {
                    context.warn("UNPARSED_TRANSACTION", "Transaction continuation is too long.", "folios.schemes.transactions", pending.location());
                    pending = null;
                } else {
                    pending = new Line(joined, pending.location());
                    if (NumericTail.read(joined, 4).values().size() == 4) { transaction(pending, state, context); pending = null; }
                }
                continue;
            }
            if (state.scheme != null && state.scheme.open == null && state.scheme.transactions.isEmpty()
                    && text.matches("(?i)^(?:Direct|Regular|Growth|Dividend|IDCW|Plan|Option|Reinvestment).*")) {
                state.scheme.name += " " + text;
                continue;
            }
            if (state.scheme != null && !state.scheme.transactions.isEmpty() && !ignorable(text)
                    && (line.cells().isEmpty() || line.cells().getFirst().x() > 50)
                    && !text.matches("(?i)^(?:Opening|Closing|Folio|Scheme|NAV|Market Value|ISIN|Registrar).*")) {
                var transactions = state.scheme.transactions;
                Transaction last = transactions.getLast();
                String description = last.description() + " " + text;
                transactions.set(transactions.size() - 1, new Transaction(last.date(), description, last.amount(), last.units(), last.nav(),
                        last.balance(), classifier.classify(description, last.units()), last.dividendRate(), last.giftFolio(), last.source()));
                continue;
            }
            if (state.scheme != null && !ignorable(text)) {
                context.warn("UNRECOGNIZED_ROW", "A row inside a scheme could not be interpreted.", "folios.schemes", line.location());
            }
        }
        if (pending != null) transaction(pending, state, context);
        var folios = state.finish(CasType.DETAILED, period, context);
        return CommonSections.finish(detection.fileType(), detection.casType(), period, investor, folios, List.of(), null, document, context);
    }

    private void transaction(Line line, MutualFundState state, ParseContext context) {
        if (state.scheme == null) {
            context.warn("ORPHAN_TRANSACTION", "A dated row has no recognized folio and scheme.", "folios", line.location());
            return;
        }
        var row = TRANSACTION.matcher(line.flat());
        if (!row.matches()) return;
        LocalDate date;
        try { date = Values.date(row.group(1)); }
        catch (IllegalArgumentException ex) {
            context.warn("INVALID_DATE", "Transaction has an invalid date.", "folios.schemes.transactions", line.location());
            return;
        }
        NumericTail tail = NumericTail.read(row.group(2), 4);
        String description = tail.prefix();
        var values = tail.values();
        BigDecimal amount = null, units = null, nav = null, balance = null;
        TransactionType preliminary = classifier.classify(description, null);
        if (values.size() == 4) {
            amount = values.get(0); units = values.get(1); nav = values.get(2); balance = values.get(3);
        } else if (values.size() == 1 && (TransactionClassifier.tax(preliminary) || preliminary == TransactionType.DIVIDEND_PAYOUT
                || preliminary == TransactionType.FEE || preliminary == TransactionType.REVERSAL)) {
            amount = values.getFirst();
        } else if (values.size() == 3 && !TransactionClassifier.tax(preliminary)) {
            amount = values.get(0); units = values.get(1); nav = values.get(2);
            context.warn("MISSING_RUNNING_BALANCE", "Transaction has no running unit balance.", "folios.schemes.transactions", line.location());
        } else if (values.isEmpty() && (preliminary == TransactionType.MISC || description.startsWith("***"))) {
            preliminary = TransactionType.MISC;
        } else {
            context.warn("UNPARSED_TRANSACTION", "A dated row has unsupported or missing numeric columns.", "folios.schemes.transactions", line.location());
            return;
        }
        TransactionType type = values.isEmpty() ? preliminary : classifier.classify(description, units);
        if (TransactionClassifier.tax(type) && units != null && units.signum() != 0)
            context.warn("TAX_HAS_UNITS", "A tax row unexpectedly contains unit movements.", "folios.schemes.transactions", line.location());
        if (TransactionClassifier.outgoing(type)) {
            // Issuers may print outflows unsigned; semantic direction is normalized.
            if (units != null) units = units.abs().negate();
            if (amount != null) amount = amount.abs().negate();
        }
        if (type == TransactionType.UNKNOWN)
            context.warn("UNKNOWN_TRANSACTION", "Transaction values were retained but its description is not classified.", "folios.schemes.transactions", line.location());
        String rate = Values.match(description, "(?:@|rate\\s*[:=]?)\\s*(?:Rs\\.?|INR|₹)?\\s*(" + Values.NUMBER + ")", 1);
        String giftFolio = (type == TransactionType.GIFT_IN || type == TransactionType.GIFT_OUT)
                ? Values.match(description, "(?:from|to)\\s+(?:folio\\s*)?(\\d[\\d/ -]*)", 1) : null;
        state.scheme.transactions.add(new Transaction(date, description, amount, units, nav, balance, type,
                rate == null ? null : Values.decimal(rate), giftFolio, line.location()));
    }

    private boolean ignorable(String text) {
        return text.matches("(?i)^(?:transaction charges|entry load|exit load|please note|\\*+\\s*note|total\\s*:|grand total|"
                + "this statement|for any queries|registrar contact|email\\s*:|www\\.).*");
    }
}
