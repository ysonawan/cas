package com.casparser.parser;

import com.casparser.parser.SourceDocument.Cell;
import com.casparser.parser.SourceDocument.Line;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Geometry-based repairs happen before issuer parsing and preserve page/line provenance. */
public final class DocumentNormalizer {
    private DocumentNormalizer() {}

    public static SourceDocument normalize(SourceDocument source) {
        List<Line> lines = new ArrayList<>(source.lines());
        for (int i = 0; i < lines.size(); i++) {
            Line prefixLine = lines.get(i);
            for (Cell prefixCell : prefixLine.cells()) {
                String prefix = prefixCell.text().replace("\u00ad", "").replace("-", "").strip();
                if (!prefix.matches("IN[A-Z0-9]{5,9}")) continue;
                boolean repaired = false;
                for (int j = i + 1; j <= Math.min(i + 3, lines.size() - 1) && !repaired; j++) {
                    Line suffixLine = lines.get(j);
                    if (suffixLine.location().page() != prefixLine.location().page()) break;
                    for (Cell suffixCell : suffixLine.cells()) {
                        String joined = prefix + suffixCell.text().strip();
                        if (Math.abs(suffixCell.x() - prefixCell.x()) > 8 || !Values.ISIN.matcher(joined).matches()) continue;
                        int target = -1;
                        for (int n = i; n <= j; n++) {
                            if (NumericTail.read(lines.get(n).text(), 10).values().size() >= 4) { target = n; break; }
                        }
                        if (target < 0) continue;
                        Line main = lines.get(target);
                        List<Cell> mainCells = new ArrayList<>(main.cells());
                        mainCells.remove(prefixCell); mainCells.remove(suffixCell);
                        mainCells.add(new Cell(joined, prefixCell.x(), main.cells().getFirst().y(), prefixCell.right()));
                        if (target != i) lines.set(i, without(lines.get(i), prefixCell));
                        if (target != j) lines.set(j, without(lines.get(j), suffixCell));
                        lines.set(target, line(main, mainCells));
                        repaired = true;
                        break;
                    }
                }
            }
        }
        return new SourceDocument(lines.stream().filter(l -> !l.text().isBlank()).toList(), source.pages(), source.metadata());
    }

    private static Line without(Line source, Cell cell) {
        List<Cell> cells = new ArrayList<>(source.cells()); cells.remove(cell); return line(source, cells);
    }
    private static Line line(Line source, List<Cell> cells) {
        cells.sort(Comparator.comparingDouble(Cell::x));
        return new Line(String.join("\t", cells.stream().map(Cell::text).toList()), source.location(), cells);
    }
}
