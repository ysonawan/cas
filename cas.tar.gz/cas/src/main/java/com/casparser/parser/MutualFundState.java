package com.casparser.parser;

import com.casparser.domain.Statement.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Mutable state is scoped to one parse and converted to immutable records at its boundary. */
final class MutualFundState {
    final Map<String, FolioState> folios = new LinkedHashMap<>();
    FolioState folio;
    SchemeState scheme;
    String amc;

    void selectFolio(String number) {
        String normalized = number.replaceAll("\\s+", "");
        String key = (amc == null ? "" : amc.toLowerCase(java.util.Locale.ROOT)) + ":" + normalized;
        folio = folios.computeIfAbsent(key, ignored -> new FolioState(normalized, amc));
        scheme = null;
    }

    void selectScheme(String name, String code, Location source) {
        if (folio == null) return;
        String key = (code == null ? name : code).replaceAll("\\s+", " ").strip();
        scheme = folio.schemes.computeIfAbsent(key, ignored -> new SchemeState(name, code, source));
    }

    List<Folio> finish(CasType casType, Period period, ParseContext context) {
        List<Folio> result = new ArrayList<>();
        for (FolioState f : folios.values()) {
            List<Scheme> schemes = new ArrayList<>();
            for (SchemeState s : f.schemes.values()) {
                String path = "folios[" + result.size() + "].schemes[" + schemes.size() + "]";
                BigDecimal calculated = s.open;
                BigDecimal running = s.open;
                if (casType == CasType.DETAILED) {
                    if (s.open == null) context.warn("MISSING_OPENING_BALANCE", "Opening units are missing; full reconciliation is unavailable.", path, s.source);
                    for (Transaction t : s.transactions) {
                        if (t.units() != null) {
                            if (calculated != null) calculated = calculated.add(t.units());
                            if (running != null) running = running.add(t.units());
                        }
                        if (t.balance() != null && running != null && differs(running, t.balance(), "0.001")) {
                            context.warn("RUNNING_BALANCE_MISMATCH", "Parsed units do not match the printed running balance.", path, t.source());
                        }
                        if (t.balance() != null) running = t.balance();
                        if (period.from() != null && t.date().isBefore(period.from()) || period.to() != null && t.date().isAfter(period.to())) {
                            context.warn("TRANSACTION_OUTSIDE_PERIOD", "A transaction date is outside the statement period.", path, t.source());
                        }
                    }
                    if (s.close == null) context.warn("MISSING_CLOSING_BALANCE", "Closing units are missing.", path, s.source);
                    if (calculated != null && s.close != null && differs(calculated, s.close, "0.001")) {
                        context.warn("CLOSING_BALANCE_MISMATCH", "Opening units plus transactions do not equal the printed closing units.", path, s.source);
                    }
                }
                if (s.nav != null && s.value != null && s.close != null && differs(s.nav.multiply(s.close), s.value, "1.00")) {
                    context.warn("VALUATION_MISMATCH", "Closing units multiplied by NAV do not match the printed valuation within one rupee.", path, s.source);
                }
                if (s.nav == null || s.value == null)
                    context.warn("MISSING_VALUATION", "NAV or market value is missing.", path, s.source);
                schemes.add(new Scheme(s.name, s.advisor, s.code, s.rta, s.isin, s.amfi,
                        s.nominees, s.open, s.close, calculated,
                        new Valuation(s.date, s.nav, s.cost, s.value), s.transactions, s.source));
            }
            if (schemes.isEmpty()) context.warn("EMPTY_FOLIO", "A folio contains no recognized schemes.", "folios[" + result.size() + "]", null);
            result.add(new Folio(f.number, f.amc, f.name, f.pan, f.kyc, f.panKyc, schemes));
        }
        return result;
    }

    static boolean differs(BigDecimal a, BigDecimal b, String tolerance) {
        return a.subtract(b).abs().compareTo(new BigDecimal(tolerance)) > 0;
    }

    static final class FolioState {
        final String number;
        final String amc;
        String name, pan, kyc, panKyc;
        final Map<String, SchemeState> schemes = new LinkedHashMap<>();
        FolioState(String number, String amc) { this.number = number; this.amc = amc; }
    }

    static final class SchemeState {
        String name, code, advisor, rta, isin, amfi, partialIsin;
        BigDecimal open, close, nav, value, cost;
        LocalDate date;
        final Location source;
        final List<String> nominees = new ArrayList<>();
        final List<Transaction> transactions = new ArrayList<>();
        SchemeState(String name, String code, Location source) { this.name = name; this.code = code; this.source = source; }
    }
}
