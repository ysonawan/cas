package com.casparser.parser;

import com.casparser.domain.Statement;
import com.casparser.domain.Statement.*;
import com.casparser.parser.SourceDocument.Line;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Holdings are scoped to accounts and asset sections. Transaction sections are never read as holdings. */
public final class DematParser implements StatementParser {
    private static final Pattern HOLDING = Pattern.compile("^\\s*(?:\\d+[.)]?\\s+)?(IN[A-Z0-9]{9}\\d)\\s+(.+)$");

    @Override public boolean supports(FileType type, CasType casType) {
        return (type == FileType.NSDL || type == FileType.CDSL) && casType == CasType.DEMAT;
    }

    @Override public Statement parse(SourceDocument document, Detection detection, ParseContext context) {
        if (document.text().contains("ACCOUNT HOLDER") || document.text().contains("HOLDING STATEMENT AS ON"))
            return new DepositoryParser().parse(document, detection, context);
        var period = CommonSections.period(document, context);
        var investor = CommonSections.investor(document, context);
        List<AccountState> accounts = new ArrayList<>();
        AccountState account = null;
        AssetType assetType = AssetType.OTHER;
        Line pending = null;
        boolean transactionSection = false, npsSection = false;
        String pran = null, npsProvider = null;
        BigDecimal npsValue = null;
        List<NpsScheme> npsSchemes = new ArrayList<>();
        List<String> columns = List.of();
        String accountName = null;
        for (Line line : document.lines()) {
            context.checkBudget();
            String text = line.flat();
            String upper = text.toUpperCase(Locale.ROOT);
            boolean boundary = text.matches("(?i).*(?:DP\\s*ID|Client\\s*ID|BO\\s*ID|Beneficiary\\s*ID)\\s*:.*")
                    || heading(text) != null || HOLDING.matcher(text).matches() || text.matches("(?i)^(?:total|grand total|national pension|NPS|transaction).*" );
            if (pending != null && boundary) {
                holding(pending, account, assetType, columns, context);
                pending = null;
            }
            if (text.matches("(?i).*(?:transaction\\s+(?:statement|details)|statement of transactions).*")) {
                transactionSection = true;
                context.warn("DEMAT_TRANSACTIONS_NOT_PARSED", "This adapter extracts holdings only; the demat transaction section is not included.", "accounts", line.location());
                continue;
            }
            if (CommonSections.noise(text)) continue;
            if (upper.contains("NATIONAL PENSION") || upper.matches("NPS(?:\\s+HOLDINGS|\\s+DETAILS)?")) {
                npsSection = true; transactionSection = false; continue;
            }
            if (npsSection) {
                String p = Values.match(text, "PRAN\\s*:\\s*([0-9X*]+)", 1);
                String provider = Values.match(text, "(?:CRA|NPS SP|Service Provider)\\s*:\\s*(.+)$", 1);
                if (p != null) { pran = p; continue; }
                if (provider != null) { npsProvider = provider; continue; }
                if (upper.startsWith("TOTAL")) {
                    var tail = NumericTail.read(text, 1);
                    if (!tail.values().isEmpty()) npsValue = tail.values().getFirst();
                    continue;
                }
                NumericTail tail = NumericTail.read(text, 3);
                if (tail.values().size() == 3 && !tail.prefix().isBlank()) {
                    String tier = Values.match(tail.prefix(), "Tier\\s*[-:]?\\s*(II|I|2|1)\\b", 1);
                    String asset = Values.match(tail.prefix(), "(?:Scheme|Asset Class)\\s*[-:]?\\s*([ECGA])\\b", 1);
                    String manager = Values.match(tail.prefix(), "^(.+?)\\s+(?:Pension|Scheme)", 1);
                    var v = tail.values();
                    npsSchemes.add(new NpsScheme(tail.prefix(), manager, tier, asset, v.get(0), v.get(1), v.get(2), line.location()));
                    checkValuation(v.get(0), v.get(1), v.get(2), "nps.schemes", line.location(), context);
                    continue;
                }
                if (!text.matches("(?i)^(?:scheme\\s+(?:name|fund)|fund manager|units|NAV|value).*"))
                    context.warn("UNPARSED_NPS_ROW", "An NPS row could not be interpreted.", "nps", line.location());
                continue;
            }
            String dp = Values.match(text, "DP\\s*ID\\s*:\\s*([A-Z0-9*]+)", 1);
            String client = Values.match(text, "Client\\s*ID\\s*:\\s*([0-9X*]+)", 1);
            String bo = Values.match(text, "(?:BO|Beneficiary)\\s*ID\\s*:\\s*([0-9X*]{16})", 1);
            String name = Values.match(text, "^(?:DP Name|Depository Participant|Account Name)\\s*:\\s*(.+)$", 1);
            if (name != null) { accountName = name; continue; }
            if (dp != null || client != null || bo != null) {
                if (dp != null || bo != null || account == null) {
                    AccountState selected = null;
                    for (AccountState candidate : accounts) {
                        if (bo != null && bo.equals(candidate.boId)
                                || dp != null && dp.equals(candidate.dpId) && client != null && client.equals(candidate.clientId)) {
                            selected = candidate; break;
                        }
                    }
                    if (selected == null) {
                        FileType accountType = bo != null || upper.contains("CDSL") ? FileType.CDSL
                                : dp != null && dp.startsWith("IN") || upper.contains("NSDL") ? FileType.NSDL : detection.fileType();
                        selected = new AccountState(accountName, accountType, line.location());
                        accounts.add(selected);
                    }
                    account = selected;
                }
                if (dp != null) account.dpId = dp;
                if (client != null) account.clientId = client;
                if (bo != null) { account.boId = bo; account.dpId = bo.substring(0, 8); account.clientId = bo.substring(8); }
                transactionSection = false; columns = List.of(); assetType = AssetType.OTHER;
                continue;
            }
            if (text.matches("(?i)^Mutual Fund Folios(?:\\s*.*)?$")) {
                account = new AccountState("Mutual Fund Folios", detection.fileType(), line.location());
                accounts.add(account); assetType = AssetType.MUTUAL_FUND; transactionSection = false; continue;
            }
            AssetType heading = heading(text);
            if (heading != null) { assetType = heading; transactionSection = false; columns = List.of(); continue; }
            if (transactionSection) continue;
            if (upper.contains("ISIN") && (upper.contains("VALUE") || upper.contains("BALANCE") || upper.contains("QUANTITY"))) {
                columns = List.of(line.text().split("\\t+| {2,}"));
                continue;
            }
            if (account != null) {
                String owner = Values.match(text, "^(?:(?:First|Second|Third)\\s+Holder|Holder(?:\\s+Name)?)\\s*:\\s*(.+?)(?=\\s+PAN|$)", 1);
                if (owner != null) {
                    account.owners.add(new Owner(owner, Values.match(text, "PAN\\s*:\\s*([A-Z0-9*]+)", 1)));
                    continue;
                }
                if (upper.matches("^(?:ACCOUNT\\s+VALUE|TOTAL\\s+ACCOUNT\\s+VALUE|PORTFOLIO\\s+VALUE).*")) {
                    NumericTail tail = NumericTail.read(text, 1);
                    if (!tail.values().isEmpty()) account.balance = tail.values().getFirst();
                    continue;
                }
            }
            if (HOLDING.matcher(text).matches()) {
                pending = line;
                if (NumericTail.read(text, 3).values().size() == 3) {
                    holding(pending, account, assetType, columns, context); pending = null;
                }
                continue;
            }
            if (pending != null) {
                pending = new Line(pending.text() + " " + text, pending.location());
                if (pending.text().length() > 4096) {
                    context.warn("UNPARSED_HOLDING", "A holding row is too long or incomplete.", "accounts.holdings", pending.location());
                    pending = null;
                } else if (NumericTail.read(pending.text(), 3).values().size() == 3) {
                    holding(pending, account, assetType, columns, context); pending = null;
                }
            } else if (account != null && !text.matches("(?i)^(?:total|grand total|note|please|this statement|PAN|email|mobile|no transactions|valuation|security name|name of).*")) {
                context.warn("UNRECOGNIZED_DEMAT_ROW", "A row in a demat account could not be interpreted.", "accounts", line.location());
            }
        }
        if (pending != null) holding(pending, account, assetType, columns, context);
        List<DematAccount> result = new ArrayList<>();
        for (var a : accounts) {
            if (a.holdings.isEmpty()) context.warn("EMPTY_ACCOUNT", "No holdings were parsed for an account.", "accounts[" + result.size() + "]", a.source);
            if (a.balance != null && a.holdings.stream().allMatch(h -> h.value() != null)) {
                BigDecimal sum = a.holdings.stream().map(Holding::value).reduce(BigDecimal.ZERO, BigDecimal::add);
                if (MutualFundState.differs(sum, a.balance, "1.00")) context.warn("ACCOUNT_VALUE_MISMATCH", "Parsed holdings do not equal the printed account value.", "accounts[" + result.size() + "]", a.source);
            }
            result.add(new DematAccount(a.name, a.type, a.dpId, a.clientId, a.boId, a.balance, a.owners, a.holdings, a.source));
        }
        Nps nps = npsSection || !npsSchemes.isEmpty() ? new Nps(pran, npsProvider, npsValue, npsSchemes) : null;
        if (nps != null && nps.value() != null && nps.schemes().stream().allMatch(s -> s.value() != null)) {
            BigDecimal sum = nps.schemes().stream().map(NpsScheme::value).reduce(BigDecimal.ZERO, BigDecimal::add);
            if (MutualFundState.differs(sum, nps.value(), "1.00")) context.warn("NPS_VALUE_MISMATCH", "Parsed NPS schemes do not equal the printed NPS value.", "nps", null);
        }
        return CommonSections.finish(detection.fileType(), detection.casType(), period, investor, List.of(), result, nps, document, context);
    }

    private AssetType heading(String text) {
        return switch (text.toUpperCase(Locale.ROOT).replaceAll("\\s*[-:]?\\s*HOLDINGS$", "").strip()) {
            case "EQUITIES", "EQUITY", "EQUITY SHARES" -> AssetType.EQUITY;
            case "MUTUAL FUNDS", "MUTUAL FUND", "MUTUAL FUND UNITS" -> AssetType.MUTUAL_FUND;
            case "BONDS", "CORPORATE BONDS", "DEBENTURES", "BONDS AND DEBENTURES", "GOVERNMENT SECURITIES" -> AssetType.BOND;
            case "ETF", "ETFS", "EXCHANGE TRADED FUNDS" -> AssetType.ETF;
            case "REIT", "REITS" -> AssetType.REIT;
            case "INVIT", "INVITS" -> AssetType.INVIT;
            default -> null;
        };
    }

    private void holding(Line line, AccountState account, AssetType assetType, List<String> columns, ParseContext context) {
        var row = HOLDING.matcher(line.flat());
        if (account == null || !row.matches()) {
            context.warn("ORPHAN_HOLDING", "A holding has no recognized account.", "accounts", line.location()); return;
        }
        String isin = row.group(1);
        NumericTail tail = NumericTail.read(row.group(2), 8);
        List<BigDecimal> values = tail.values();
        BigDecimal units = null, price = null, value = null, cost = null, face = null, coupon = null;
        String name = tail.prefix();
        String folio = null;
        if (values.size() == 3) {
            units = values.get(0); price = values.get(1); value = values.get(2);
        } else {
            // Richer tables require explicit column labels; guessing the last three would
            // confuse NAV, cost, unrealized gain and percentage-return columns.
            String[] cells = line.text().split("\\t+| {2,}");
            if (cells.length == columns.size() && cells.length >= 4) {
                try {
                    for (int i = 0; i < cells.length; i++) {
                        String label = columns.get(i).toLowerCase(Locale.ROOT).strip();
                        if (label.matches(".*(?:quantity|units|current balance|free balance|shares).*")) units = Values.decimal(cells[i]);
                        else if (label.matches(".*(?:face value).*")) face = Values.decimal(cells[i]);
                        else if (label.matches(".*(?:coupon).*")) coupon = Values.decimal(cells[i].replace("%", ""));
                        else if (label.matches(".*(?:nav|market price|rate).*")) price = Values.decimal(cells[i]);
                        else if (label.matches(".*(?:market value|current value|valuation|value).*")) value = Values.decimal(cells[i]);
                        else if (label.matches(".*cost.*")) cost = Values.decimal(cells[i]);
                        else if (label.matches(".*folio.*")) folio = cells[i].strip();
                        else if (label.matches(".*(?:name|security|description).*")) name = cells[i].strip();
                    }
                } catch (IllegalArgumentException ex) {
                    context.warn("INVALID_HOLDING_NUMBER", "A holding contains an invalid numeric cell.", "accounts.holdings", line.location()); return;
                }
            }
            if (units == null || value == null) {
                context.warn("UNPARSED_HOLDING", "A holding has an unsupported column arrangement.", "accounts.holdings", line.location()); return;
            }
        }
        if (assetType == AssetType.OTHER) context.warn("UNKNOWN_ASSET_TYPE", "A holding was retained without a recognized asset section.", "accounts.holdings", line.location());
        if (units == null || price == null || value == null)
            context.warn("MISSING_HOLDING_VALUE", "A holding contains missing quantity, price or value.", "accounts.holdings", line.location());
        checkValuation(units, price, value, "accounts.holdings", line.location(), context);
        account.holdings.add(new Holding(isin, name, assetType, folio, units, price, value, cost, face, coupon, null, line.location()));
    }

    private static void checkValuation(BigDecimal units, BigDecimal price, BigDecimal value, String path, Location source, ParseContext context) {
        if (units != null && price != null && value != null && MutualFundState.differs(units.multiply(price), value, "1.00"))
            context.warn("HOLDING_VALUE_MISMATCH", "Quantity multiplied by price does not match the printed value within one rupee.", path, source);
    }

    private static final class AccountState {
        final String name;
        final FileType type;
        final Location source;
        String dpId, clientId, boId;
        BigDecimal balance;
        final List<Owner> owners = new ArrayList<>();
        final List<Holding> holdings = new ArrayList<>();
        AccountState(String name, FileType type, Location source) { this.name = name; this.type = type; this.source = source; }
    }
}
