package com.casparser.parser;

import com.casparser.domain.ParseException;
import com.casparser.domain.Statement;
import java.util.List;

/** Pure Java entry point, independent of Spring and PDFBox. */
public final class ParserEngine {
    private final StatementDetector detector;
    private final List<StatementParser> parsers;

    public ParserEngine(StatementDetector detector, List<StatementParser> parsers) {
        this.detector = detector;
        this.parsers = List.copyOf(parsers);
    }

    public Statement parse(SourceDocument document, boolean strict, ParseContext context) {
        context.checkBudget();
        document = DocumentNormalizer.normalize(document);
        var detection = detector.detect(document);
        var matches = parsers.stream().filter(p -> p.supports(detection.fileType(), detection.casType())).toList();
        if (matches.size() != 1) throw new ParseException("PARSER_CONFIGURATION", 500,
                "Exactly one parser must be registered for the detected statement format.");
        Statement statement = matches.getFirst().parse(document, detection, context);
        context.checkBudget();
        if (strict && !statement.warnings().isEmpty()) throw new ParseException("STRICT_VALIDATION_FAILED", 422,
                "The statement contains parsing or reconciliation warnings.", statement.warnings());
        return statement;
    }
}
