package com.casparser.parser;

import com.casparser.domain.Statement.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

final class NpsSections {
    private static final Pattern TRANSACTION = Pattern.compile("^(" + Values.DATE + ")\\s+(.+?)\\s+(CR|DR)\\s+(.+)$", Pattern.CASE_INSENSITIVE);

    private NpsSections() {}
    static Nps parse(SourceDocument document, ParseContext context) {
        boolean active = false, transactionMode = false;
        String pran = null, provider = null, scheme = null;
        BigDecimal value = null, running = null;
        List<NpsScheme> schemes = new ArrayList<>();
        List<NpsTransaction> transactions = new ArrayList<>();
        for (var line : document.lines()) {
            String text = line.flat(), upper = text.toUpperCase(Locale.ROOT);
            if (upper.startsWith("NATIONAL PENSION SYSTEM (NPS) HOLDING DETAILS")) { active = true; transactionMode = false; continue; }
            if (upper.startsWith("NATIONAL PENSION SYSTEM (NPS) TRANSACTION DETAILS")) { active = true; transactionMode = true; continue; }
            if (upper.equals("TRANSACTIONS") || upper.contains("***END OF STATEMENT***")) { active = false; continue; }
            if (text.contains("[CRA for National Pension System")) provider = text.substring(0, text.indexOf('[')).strip();
            if (!active) continue;
            String p = Values.match(text, "PRAN\\s*:\\s*([0-9X*]+)", 1);
            if (p != null) { pran = p; continue; }
            if (!transactionMode && upper.startsWith("NPS TRUST")) {
                var tail = NumericTail.read(line.text(), 3);
                if (tail.values().size() != 3) { context.warn("UNPARSED_NPS_ROW", "An NPS holding has missing numeric cells.", "nps.schemes", line.location()); continue; }
                var v = tail.values();
                schemes.add(new NpsScheme(tail.prefix(), Values.match(tail.prefix(), "A/C\\s+(.+?)\\s+SCHEME", 1),
                        Values.match(tail.prefix(), "TIER\\s+(II|I)\\b", 1), Values.match(tail.prefix(), "SCHEME\\s+([ECGA])\\b", 1),
                        v.get(0), v.get(1), v.get(2), line.location()));
                continue;
            }
            if (!transactionMode && upper.matches("TOTAL\\s+.*")) {
                var tail = NumericTail.read(text, 1);
                if (!tail.values().isEmpty()) value = tail.values().getFirst();
                active = false;
                continue;
            }
            if (transactionMode && upper.startsWith("NPS TRUST")) { scheme = text; running = null; continue; }
            if (transactionMode && upper.startsWith("OPENING BALANCE")) {
                var tail = NumericTail.read(text, 1);
                if (!tail.values().isEmpty()) running = tail.values().getFirst();
                continue;
            }
            if (transactionMode && upper.startsWith("CLOSING BALANCE")) {
                var tail = NumericTail.read(text, 1);
                if (running != null && !tail.values().isEmpty() && MutualFundState.differs(running, tail.values().getFirst(), "0.02"))
                    context.warn("NPS_UNIT_BALANCE_MISMATCH", "NPS opening units plus transactions do not equal the printed closing units within the displayed rounding tolerance.", "nps.transactions", line.location());
                continue;
            }
            var row = TRANSACTION.matcher(line.text());
            if (transactionMode && row.matches()) {
                var tail = NumericTail.read(row.group(4), 3);
                if (tail.values().size() != 3) { context.warn("UNPARSED_NPS_TRANSACTION", "NPS transaction columns are incomplete.", "nps.transactions", line.location()); continue; }
                var v = tail.values();
                BigDecimal units = "DR".equalsIgnoreCase(row.group(3)) ? v.get(2).negate() : v.get(2);
                try {
                    transactions.add(new NpsTransaction(Values.date(row.group(1)), scheme, row.group(2), v.get(0), v.get(1), units, row.group(3), line.location()));
                    if (running != null) running = running.add(units);
                } catch (IllegalArgumentException ex) { context.warn("INVALID_DATE", "NPS transaction date is invalid.", "nps.transactions", line.location()); }
            }
        }
        if (schemes.isEmpty() && transactions.isEmpty()) return null;
        if (value != null && schemes.stream().allMatch(s -> s.value() != null)) {
            BigDecimal sum = schemes.stream().map(NpsScheme::value).reduce(BigDecimal.ZERO, BigDecimal::add);
            if (MutualFundState.differs(value, sum, "1.00")) context.warn("NPS_VALUE_MISMATCH", "NPS holdings do not match the printed total.", "nps", null);
        }
        return new Nps(pran, provider, value, schemes, transactions);
    }
}
