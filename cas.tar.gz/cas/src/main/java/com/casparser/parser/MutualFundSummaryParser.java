package com.casparser.parser;

import com.casparser.domain.Statement;
import com.casparser.domain.Statement.*;
import com.casparser.parser.SourceDocument.Line;
import java.util.List;
import java.util.regex.Pattern;

/** Supports summary tables (scheme, folio, units, NAV date, NAV, value) and labeled blocks. */
public final class MutualFundSummaryParser implements StatementParser {
    private static final Pattern TABLE = Pattern.compile("^(.+?)\\s+(\\d[\\d*/-]*(?:\\s*/\\s*\\d+)?)\\s+(" + Values.NUMBER
            + ")\\s+(" + Values.DATE + ")\\s+(" + Values.NUMBER + ")\\s+(" + Values.NUMBER + ")(?:\\s+(CAMS|KFINTECH|KARVY))?$", Pattern.CASE_INSENSITIVE);

    @Override public boolean supports(FileType type, CasType casType) {
        return (type == FileType.CAMS || type == FileType.KFINTECH) && casType == CasType.SUMMARY;
    }

    @Override public Statement parse(SourceDocument document, Detection detection, ParseContext context) {
        var period = CommonSections.period(document, context);
        var investor = CommonSections.investor(document, context);
        MutualFundState state = new MutualFundState();
        String pending = "";
        boolean tableStarted = false;
        for (Line line : document.lines()) {
            context.checkBudget();
            String text = line.flat();
            if (CommonSections.noise(text)) continue;
            if (text.matches("(?i).*(?:scheme.*folio|folio.*scheme|unit.*nav.*value).*")) { tableStarted = true; continue; }
            var row = TABLE.matcher((pending + " " + text).strip());
            if (!row.matches()) row = TABLE.matcher(text);
            if (row.matches()) {
                String name = row.group(1);
                String isin = Values.match(name, "\\b(IN[A-Z0-9]{9}\\d)\\b", 1);
                name = name.replaceAll("\\bIN[A-Z0-9]{9}\\d\\b", "").strip();
                state.selectFolio(row.group(2));
                state.selectScheme(name, null, line.location());
                var s = state.scheme;
                s.isin = isin;
                s.close = Values.decimal(row.group(3));
                try { s.date = Values.date(row.group(4)); }
                catch (IllegalArgumentException ex) { context.warn("INVALID_DATE", "A summary row has an invalid NAV date.", "folios.schemes.valuation", line.location()); }
                s.nav = Values.decimal(row.group(5));
                s.value = Values.decimal(row.group(6));
                s.rta = row.group(7);
                pending = "";
                tableStarted = true;
                continue;
            }
            if (MutualFundSections.structural(line, state, context)) { pending = ""; continue; }
            if (state.scheme != null) {
                String units = Values.match(text, "^(?:units|unit balance|balance units)\\s*:\\s*(" + Values.NUMBER + ")", 1);
                if (units != null) { state.scheme.close = Values.decimal(units); continue; }
            }
            if (text.matches("(?i)^(?:total|grand total|please|note|this statement|PAN|KYC|email|mobile).*")) {
                if (!pending.isBlank()) context.warn("UNPARSED_SUMMARY_ROW", "A summary table row is incomplete.", "folios", line.location());
                pending = "";
                continue;
            }
            if (tableStarted || state.amc != null) {
                if (pending.length() + text.length() > 2048) {
                    context.warn("UNPARSED_SUMMARY_ROW", "A summary table row could not be interpreted.", "folios", line.location());
                    pending = "";
                }
                pending = (pending + " " + text).strip();
            }
        }
        if (!pending.isBlank()) context.warn("UNPARSED_SUMMARY_ROW", "A summary table row is incomplete.", "folios", null);
        return CommonSections.finish(detection.fileType(), detection.casType(), period, investor,
                state.finish(CasType.SUMMARY, period, context), List.of(), null, document, context);
    }
}
