package com.casparser.parser;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** Separates right-aligned table cells without treating digits within a description as amounts. */
public record NumericTail(String prefix, List<BigDecimal> values) {
    public static NumericTail read(String text, int maximum) {
        String remaining = text.strip();
        List<BigDecimal> values = new ArrayList<>();
        if (remaining.indexOf('\t') >= 0) {
            String[] cells = remaining.split("\\t+");
            int end = cells.length - 1;
            while (end >= 0 && values.size() < maximum && Values.isNumber(cells[end])) values.add(0, Values.decimal(cells[end--]));
            return new NumericTail(String.join(" ", java.util.Arrays.copyOfRange(cells, 0, end + 1)).strip(), java.util.Collections.unmodifiableList(values));
        }
        while (!remaining.isBlank() && values.size() < maximum) {
            int split = Math.max(remaining.lastIndexOf(' '), remaining.lastIndexOf('\t'));
            String token = remaining.substring(split + 1);
            if ((token.equalsIgnoreCase("CR") || token.equalsIgnoreCase("DR")) && split >= 0) {
                int previous = Math.max(remaining.lastIndexOf(' ', split - 1), remaining.lastIndexOf('\t', split - 1));
                token = remaining.substring(previous + 1);
                split = previous;
            }
            if (!Values.isNumber(token)) break;
            values.add(0, Values.decimal(token));
            remaining = split < 0 ? "" : remaining.substring(0, split).stripTrailing();
        }
        // List.copyOf rejects null; null here is a meaningful blank cell, e.g. '-'.
        return new NumericTail(remaining, java.util.Collections.unmodifiableList(values));
    }
}
