package com.casparser.parser;

import com.casparser.domain.Statement;
import com.casparser.domain.Statement.*;
import com.casparser.parser.SourceDocument.Line;
import com.casparser.parser.StatementParser.Detection;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/** NSDL and bilingual CDSL tabular templates. Section state prevents summary/transaction duplication. */
final class DepositoryParser {
    private enum Mode { SUMMARY, HOLDINGS, TRANSACTIONS, INFO }
    private enum Layout { NSDL_EQUITY, NSDL_CDSL, CDSL, MF_FOLIOS, MF_CDSL, UNKNOWN }
    private static final Pattern DATED = Pattern.compile("^(" + Values.DATE + ")\\s+(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern ISIN_ROW = Pattern.compile("^(IN[A-Z0-9]{9}\\d)\\s+(.+)$");
    private final TransactionClassifier classifier = new TransactionClassifier();

    Statement parse(SourceDocument document, Detection detection, ParseContext context) {
        var period = CommonSections.period(document, context);
        var investor = CommonSections.investor(document, context);
        Map<String, Account> accounts = new LinkedHashMap<>();
        Map<String, SummaryAccount> summary = new LinkedHashMap<>();
        Account current = null;
        Mode mode = Mode.SUMMARY;
        Layout layout = Layout.UNKNOWN;
        AssetType asset = AssetType.OTHER;
        FileType accountType = detection.fileType();
        String isin = null, folio = null;
        String lastAccountName = null;
        BigDecimal lastSummaryValue = null;
        int lastSummaryCount = -1;
        float nameLeft = -1;
        boolean nativeCdsl = detection.fileType() == FileType.CDSL;
        boolean mfTransactions = false;
        boolean sawTransactionSection = false;
        boolean npsSection = false;
        List<Line> lines = document.lines();
        for (int i = 0; i < lines.size(); i++) {
            context.checkBudget();
            Line line = lines.get(i);
            String text = line.flat(), upper = text.toUpperCase(Locale.ROOT);
            if (upper.equals("TRANSACTIONS") || upper.startsWith("STATEMENT OF TRANSACTIONS") || upper.startsWith("MUTUAL FUNDS TRANSACTION STATEMENT")) {
                npsSection = false;
                mode = Mode.TRANSACTIONS; sawTransactionSection = true;
                if (upper.startsWith("MUTUAL FUNDS TRANSACTION")) mfTransactions = true;
                continue;
            }
            if (upper.startsWith("NATIONAL PENSION SYSTEM (NPS) HOLDING DETAILS") || upper.startsWith("NATIONAL PENSION SYSTEM (NPS) TRANSACTION DETAILS")) {
                npsSection = true; continue;
            }
            if (npsSection) {
                if (upper.matches("TOTAL\\s+" + Values.NUMBER)) { npsSection = false; mode = Mode.SUMMARY; }
                continue;
            }
            if (upper.startsWith("KNOW MORE ABOUT YOUR ACCOUNTS") || upper.contains("***END OF STATEMENT***") || upper.startsWith("NOTES TO CAS")) {
                mode = Mode.INFO; continue;
            }
            if (mode == Mode.INFO) continue;
            if (upper.equals("ACCOUNT HOLDER") && mode != Mode.TRANSACTIONS) {
                mode = Mode.HOLDINGS;
                if (i + 1 < lines.size()) lastAccountName = lines.get(i + 1).flat();
                continue;
            }
            if (upper.startsWith("HOLDING STATEMENT AS ON")) {
                mode = Mode.HOLDINGS; layout = Layout.CDSL; continue;
            }
            if (upper.startsWith("MUTUAL FUND UNITS HELD AS ON")) {
                current = accounts.computeIfAbsent("MF", ignored -> new Account("Mutual Fund Folios", detection.fileType(), null, null, null, line.location()));
                SummaryAccount expected = summary.get("MF");
                if (expected != null) { current.balance = expected.value; current.expectedCount = expected.count; }
                mode = Mode.HOLDINGS; layout = Layout.MF_CDSL; asset = AssetType.MUTUAL_FUND;
                continue;
            }
            if (upper.startsWith("MUTUAL FUND UNITS HELD WITH")) {
                current = accounts.computeIfAbsent("MF", ignored -> new Account("Mutual Fund Folios", detection.fileType(), null, null, null, line.location()));
                mode = Mode.TRANSACTIONS; mfTransactions = true; continue;
            }
            if (upper.matches("(?:NSDL|CDSL) DEMAT ACCOUNT")) {
                accountType = upper.startsWith("NSDL") ? FileType.NSDL : FileType.CDSL;
                mfTransactions = false;
                continue;
            }
            // Summary account totals and counts come from their own rows; actual accounts are
            // only materialized when their detail section is encountered.
            if (mode == Mode.SUMMARY && upper.matches("(?:NSDL|CDSL) DEMAT ACCOUNT\\s+.*")) {
                var numeric = NumericTail.read(text, 2);
                if (numeric.values().size() == 2) {
                    lastSummaryCount = numeric.values().get(0).intValueExact(); lastSummaryValue = numeric.values().get(1);
                    lastAccountName = i > 0 ? lines.get(i - 1).flat() : null;
                    accountType = upper.startsWith("NSDL") ? FileType.NSDL : FileType.CDSL;
                }
                continue;
            }
            if (mode == Mode.SUMMARY && upper.startsWith("MUTUAL FUND FOLIOS") && text.matches(".*\\d+\\s+Folios.*")) {
                var numeric = NumericTail.read(text, 2);
                if (numeric.values().size() == 2) {
                    var previous = summary.get("MF");
                    summary.put("MF", new SummaryAccount("Mutual Fund Folios", detection.fileType(),
                            numeric.values().get(1).add(previous == null ? BigDecimal.ZERO : previous.value),
                            numeric.values().get(0).intValueExact() + (previous == null ? 0 : previous.count)));
                }
                continue;
            }
            String dp = Values.match(text, "DP\\s*ID\\s*:\\s*([A-Z0-9*]+)", 1);
            String client = Values.match(text, "Client\\s*ID\\s*:\\s*([0-9X*]+)", 1);
            String bo = Values.match(text, "BO\\s*ID\\s*:\\s*([0-9X*]{16})", 1);
            String combinedNsdl = Values.match(text, "DPID\\s*:\\s*I?(IN\\d{14})", 1);
            if (combinedNsdl != null) { dp = combinedNsdl.substring(0, 8); client = combinedNsdl.substring(8); accountType = FileType.NSDL; mode = Mode.HOLDINGS; }
            if (bo != null) { dp = bo.substring(0, 8); client = bo.substring(8); accountType = FileType.CDSL; }
            if (dp != null && client != null) {
                String key = dp + ":" + client;
                if (mode == Mode.SUMMARY && bo == null) {
                    summary.put(key, new SummaryAccount(lastAccountName, accountType, lastSummaryValue, lastSummaryCount));
                    lastSummaryCount = -1; lastSummaryValue = null;
                    continue;
                }
                if (bo != null) mode = Mode.HOLDINGS;
                SummaryAccount expected = summary.get(key);
                if (expected != null) lastAccountName = expected.name;
                current = accounts.get(key);
                if (current == null) {
                    current = new Account(lastAccountName, accountType, dp, client, bo, line.location());
                    accounts.put(key, current);
                }
                if (expected != null) { current.balance = expected.value; current.expectedCount = expected.count; }
                if (investor.name() != null && current.owners.isEmpty()) current.owners.add(new Owner(investor.name(), investor.pan()));
                layout = Layout.UNKNOWN; asset = AssetType.OTHER; isin = null; folio = null;
                continue;
            }
            if (upper.matches("MUTUAL FUND FOLIOS(?: \\(F\\))?")) {
                current = accounts.computeIfAbsent("MF", ignored -> new Account("Mutual Fund Folios", detection.fileType(), null, null, null, line.location()));
                SummaryAccount expected = summary.get("MF");
                if (expected != null) { current.balance = expected.value; current.expectedCount = expected.count; }
                mfTransactions = mode == Mode.TRANSACTIONS;
                if (mode != Mode.TRANSACTIONS) { mode = Mode.HOLDINGS; layout = Layout.MF_FOLIOS; asset = AssetType.MUTUAL_FUND; }
                continue;
            }
            if (mode == Mode.SUMMARY) continue;
            if (current == null) continue;
            AssetType heading = assetHeading(upper);
            if (heading != null) { asset = heading; continue; }
            if (upper.startsWith("ISIN") && (upper.contains("COMPANY NAME") || upper.contains("SECURITY") || upper.contains("ISIN DESCRIPTION"))) {
                if (upper.contains("COMPANY NAME")) layout = Layout.NSDL_EQUITY;
                else if (upper.contains("SAFEKEEP")) layout = Layout.NSDL_CDSL;
                else if (upper.contains("ISIN DESCRIPTION")) layout = Layout.MF_FOLIOS;
                for (var cell : line.cells()) {
                    if (cell.text().matches("(?i).*(?:Company Name|Security|ISIN Description).*")) nameLeft = cell.x();
                }
                continue;
            }
            if (mode == Mode.TRANSACTIONS) {
                String transactionIsin = Values.match(text, "^ISIN\\s*:\\s*(IN[A-Z0-9]{9}\\d)", 1);
                if (transactionIsin == null) transactionIsin = Values.match(text, "^ISIN\\s+(IN[A-Z0-9]{9}\\d)", 1);
                if (transactionIsin != null) {
                    isin = transactionIsin;
                    String inlineFolio = Values.match(text, "Folio No\\s*[-:]\\s*([0-9/]+)", 1);
                    if (inlineFolio != null || !nativeCdsl) folio = inlineFolio;
                }
                if (nativeCdsl && text.startsWith("Folio No")) folio = Values.match(text, "Folio No\\s*:\\s*([0-9/]+)", 1);
                if (nativeCdsl && text.startsWith("ISIN :")) isin = Values.match(text, "ISIN\\s*:\\s*(IN[A-Z0-9]{9}\\d)", 1);
                var dated = DATED.matcher(text);
                if (dated.matches() || text.matches("(?i)^(?:Opening|Closing) Balance.*")) {
                    transaction(line, current, isin, folio, mfTransactions, nativeCdsl, context);
                }
                continue;
            }
            if (upper.startsWith("PORTFOLIO VALUE") || upper.matches("TOTAL\\s+" + Values.NUMBER)) {
                String total = Values.match(text, "(?:Portfolio Value|Total)\\s*(?:₹|`)?\\s*(" + Values.NUMBER + ")", 1);
                if (total != null && !(current.dp == null && summary.containsKey("MF"))) current.balance = Values.decimal(total);
                continue;
            }
            if (upper.startsWith("GRAND TOTAL") && layout == Layout.MF_CDSL) {
                var tail = NumericTail.read(text, 2);
                if (!tail.values().isEmpty()) current.balance = tail.values().getLast();
                mode = Mode.INFO;
                continue;
            }
            if (upper.startsWith("NOTES:") || upper.startsWith("LOAD STRUCTURES")) { mode = Mode.SUMMARY; continue; }
            var holding = ISIN_ROW.matcher(text);
            if (holding.matches() || layout == Layout.MF_CDSL && Values.ISIN.matcher(text).find()) {
                Holding parsed = holding(document, i, current, layout, asset, nameLeft, context);
                if (parsed != null) current.holdings.add(parsed);
            }
        }
        List<DematAccount> result = new ArrayList<>();
        for (Account account : accounts.values()) {
            String path = "accounts[" + result.size() + "]";
            if (account.expectedCount >= 0 && account.holdings.size() != account.expectedCount)
                context.warn("HOLDING_COUNT_MISMATCH", "Parsed holdings do not match the statement's account summary count.", path, account.source);
            if (account.balance != null && account.holdings.stream().allMatch(h -> h.value() != null)) {
                BigDecimal sum = account.holdings.stream().map(Holding::value).reduce(BigDecimal.ZERO, BigDecimal::add);
                if (MutualFundState.differs(sum, account.balance, "1.00")) context.warn("ACCOUNT_VALUE_MISMATCH", "Parsed holdings do not match the printed account total.", path, account.source);
            }
            List<SecurityBalance> balances = new ArrayList<>();
            for (var b : account.balances.values()) {
                BigDecimal calculated = b.open == null ? null : b.open.add(b.movement);
                if (b.close != null && calculated != null && MutualFundState.differs(b.close, calculated, "0.001"))
                    context.warn("SECURITY_BALANCE_MISMATCH", "Opening balance plus parsed transactions does not match closing balance.", path + ".security_balances", account.source);
                balances.add(new SecurityBalance(b.isin, b.folio, b.open, b.close, calculated));
            }
            result.add(new DematAccount(account.name, account.type, account.dp, account.client, account.bo, account.balance,
                    account.owners, account.holdings, account.transactions, balances, account.source));
        }
        if (sawTransactionSection && result.stream().allMatch(a -> a.transactions().isEmpty()) && document.text().matches("(?s).*\\d{2}[-/][A-Za-z0-9]{2,3}[-/]\\d{4}\\t.*"))
            context.warn("NO_DEMAT_TRANSACTIONS", "Transaction sections were found but no supported transaction rows were parsed.", "accounts.transactions", null);
        return CommonSections.finish(detection.fileType(), CasType.DEMAT, period, investor, List.of(), result, NpsSections.parse(document, context), document, context);
    }

    private Holding holding(SourceDocument document, int index, Account account, Layout layout, AssetType asset, float nameLeft, ParseContext context) {
        Line line = document.lines().get(index);
        String text = line.flat();
        var isinMatcher = Values.ISIN.matcher(text);
        if (!isinMatcher.find()) return null;
        String isin = isinMatcher.group(1);
        NumericTail tail = NumericTail.read(line.text().substring(line.text().indexOf(isin) + isin.length()), 12);
        List<BigDecimal> v = tail.values();
        BigDecimal units = null, price = null, value = null, cost = null, face = null, average = null, gain = null, annual = null;
        String folio = null;
        Map<String, BigDecimal> balances = new LinkedHashMap<>();
        if (layout == Layout.NSDL_EQUITY && text.contains("See Note")) {
            String[] cells = line.text().split("\\t+");
            if (cells.length >= 6) {
                face = Values.decimal(cells[cells.length - 4]); units = Values.decimal(cells[cells.length - 3]); value = Values.decimal(cells[cells.length - 1]);
                context.warn("PRICE_REFERENCES_NOTE", "The printed price refers to an issuer note; value is preserved and price is null.", "accounts.holdings", line.location());
            }
        } else if (layout == Layout.NSDL_EQUITY && v.size() == 4) {
            face = v.get(0); units = v.get(1); price = v.get(2); value = v.get(3);
        } else if (layout == Layout.NSDL_CDSL && v.size() == 5) {
            units = v.get(0); balances.put("safekeep", v.get(1)); balances.put("pledged", v.get(2)); price = v.get(3); value = v.get(4);
        } else if (layout == Layout.CDSL && v.size() == 7) {
            units = v.get(0); balances.put("frozen", v.get(1)); balances.put("pledged", v.get(2));
            balances.put("pledge_setup", v.get(3)); balances.put("free", v.get(4)); price = v.get(5); value = v.get(6);
        } else if (layout == Layout.MF_FOLIOS && v.size() >= 6) {
            // Folio is an identifier, even when all its characters happen to be digits.
            String[] cells = line.text().split("\\t+");
            if (cells.length >= 3) folio = cells[2].strip();
            int offset = folio != null && Values.isNumber(folio) && !v.isEmpty() && Values.decimal(folio).compareTo(v.getFirst()) == 0 ? 1 : 0;
            if (v.size() - offset < 6) { context.warn("UNPARSED_HOLDING", "Mutual fund holding has missing columns.", "accounts.holdings", line.location()); return null; }
            units = v.get(offset); average = v.get(offset + 1); cost = v.get(offset + 2);
            price = v.get(offset + 3); value = v.get(offset + 4); gain = v.get(offset + 5); annual = v.size() > offset + 6 ? v.get(offset + 6) : null;
            asset = AssetType.MUTUAL_FUND;
        } else if (layout == Layout.MF_CDSL && v.size() >= 4) {
            folio = Values.match(text.substring(isinMatcher.end()), "^\\s*([0-9/]+)", 1);
            int offset = folio != null && Values.isNumber(folio) && !v.isEmpty() && Values.decimal(folio).compareTo(v.getFirst()) == 0 ? 1 : 0;
            units = v.get(offset); price = v.get(offset + 1); cost = v.get(offset + 2); value = v.get(offset + 3);
            if (v.size() > offset + 4) gain = v.get(offset + 4);
            if (v.size() > offset + 5) annual = v.get(offset + 5);
            asset = AssetType.MUTUAL_FUND;
        } else if (v.size() == 3) {
            units = v.get(0); price = v.get(1); value = v.get(2);
        } else {
            context.warn("UNPARSED_HOLDING", "The holding column count does not match its table header.", "accounts.holdings", line.location());
            return null;
        }
        String name = layout == Layout.MF_CDSL ? text.substring(0, isinMatcher.start()).strip() : tail.prefix();
        name = fullName(document, index, nameLeft, layout, name);
        String ucc = null;
        if (layout == Layout.MF_FOLIOS && index + 1 < document.lines().size()) {
            String candidate = document.lines().get(index + 1).text().split("\\t", 2)[0];
            if (candidate.matches("[A-Z][A-Z0-9]{3,30}") && !candidate.equals("NOT AVAILABLE")) ucc = candidate;
        }
        if (layout == Layout.NSDL_CDSL) {
            String[] keys = {"free", "locked_in", "earmarked", "lent", "pledge_setup", "pledgee"};
            int key = 0;
            for (int n = index + 1; n < Math.min(document.lines().size(), index + 5) && key < keys.length; n++) {
                var next = document.lines().get(n);
                if (Values.ISIN.matcher(next.text()).find()) break;
                var more = NumericTail.read(next.text(), 3);
                if (more.values().size() == 3) for (var balance : more.values()) balances.put(keys[key++], balance);
            }
        }
        if (asset == AssetType.OTHER) {
            if (isin.startsWith("INF")) asset = name.toUpperCase(Locale.ROOT).contains("ETF") ? AssetType.ETF : AssetType.MUTUAL_FUND;
            else if (name.matches("(?i).*(?:BOND|DEBENTURE|SGB).*")) asset = AssetType.BOND;
            else if (name.matches("(?i).*(?:EQUITY|EQ SH|SHARES).*")) asset = AssetType.EQUITY;
            else context.warn("UNKNOWN_ASSET_TYPE", "The security type could not be identified from its section or description.", "accounts.holdings", line.location());
        }
        if (units != null && price != null && value != null && units.multiply(price).subtract(value).abs().compareTo(
                units.abs().multiply(BigDecimal.valueOf(5).scaleByPowerOfTen(-price.scale() - 1)).add(new BigDecimal("0.01")).max(BigDecimal.ONE)) > 0)
            context.warn("HOLDING_VALUE_MISMATCH", "Quantity times price differs from the printed holding value by more than one rupee.", "accounts.holdings", line.location());
        return new Holding(isin, name, asset, folio, units, price, value, cost, face, null, null, line.location(), balances, average, gain, annual, ucc);
    }

    private String fullName(SourceDocument document, int index, float headerX, Layout layout, String fallback) {
        var lines = document.lines();
        Line main = lines.get(index);
        if (main.cells().isEmpty()) return fallback;
        float left = headerX;
        if (layout == Layout.MF_CDSL) left = 0;
        else if (Values.ISIN.matcher(main.cells().getFirst().text()).matches()) left = main.cells().getFirst().right() + 1;
        if (left < 0 && main.cells().size() > 1 && !Values.isNumber(main.cells().get(1).text())) left = main.cells().get(1).x();
        if (left < 0) return fallback;
        float right = Float.MAX_VALUE;
        for (var cell : main.cells()) if (cell.x() > left + 20 && (Values.isNumber(cell.text()) || Values.ISIN.matcher(cell.text()).matches())) { right = cell.x() - 4; break; }
        float y = main.cells().getFirst().y();
        boolean topAligned = layout == Layout.NSDL_EQUITY || layout == Layout.NSDL_CDSL || layout == Layout.MF_FOLIOS;
        float low = y - 30, high = y + 30;
        for (int n = index - 1; n >= Math.max(0, index - 12); n--) {
            Line previous = lines.get(n);
            if (previous.location().page() != main.location().page()) break;
            if (Values.ISIN.matcher(previous.text()).find() && !previous.text().contains("ISIN")) {
                if (!previous.cells().isEmpty()) low = (y + previous.cells().getFirst().y()) / 2; break;
            }
            if (previous.flat().matches("(?i)^(?:ISIN.*|HOLDING STATEMENT.*|Price /|Current.*|Bal|Face|Value)$")) {
                if (!previous.cells().isEmpty()) low = previous.cells().getFirst().y() + 1; break;
            }
        }
        if (topAligned) low = y - 0.5f;
        for (int n = index + 1; n < Math.min(lines.size(), index + 12); n++) {
            Line next = lines.get(n);
            if (next.location().page() != main.location().page()) break;
            if (Values.ISIN.matcher(next.text()).find() && !next.text().contains("ISIN")) {
                if (!next.cells().isEmpty()) high = topAligned ? next.cells().getFirst().y() - 0.5f : (y + next.cells().getFirst().y()) / 2; break;
            }
            if (next.flat().matches("(?i)^(?:Sub Total|Total|Portfolio Value|Grand Total|Page|Mutual Funds|Equities).*")) {
                if (!next.cells().isEmpty()) high = next.cells().getFirst().y() - 1; break;
            }
        }
        List<String> parts = new ArrayList<>();
        for (int n = Math.max(0, index - 10); n < Math.min(lines.size(), index + 11); n++) {
            for (var cell : lines.get(n).cells()) {
                if (lines.get(n).location().page() == main.location().page() && cell.y() >= low && cell.y() <= high
                        && cell.x() >= left - 4 && cell.x() < right && !Values.ISIN.matcher(cell.text()).find()
                        && !Values.isNumber(cell.text()) && !cell.text().matches("(?i)^(?:NOT AVAILABLE|MF[A-Z0-9]+|TRADING SUSPENDED|.*\\.NSE|.*\\.BSE)$")) parts.add(cell.text());
            }
        }
        return parts.isEmpty() ? fallback : String.join(" ", parts).replaceAll("\\s+", " ").strip();
    }

    private void transaction(Line line, Account account, String isin, String folio, boolean mutualFund, boolean nativeCdsl, ParseContext context) {
        String text = line.flat();
        var dated = DATED.matcher(line.text());
        LocalDate date = null;
        String rest = text;
        if (dated.matches()) {
            try { date = Values.date(dated.group(1)); }
            catch (IllegalArgumentException ex) { context.warn("INVALID_DATE", "Invalid transaction date.", "accounts.transactions", line.location()); return; }
            rest = dated.group(2);
        }
        NumericTail tail = NumericTail.read(rest, 10);
        if (isin == null) {
            context.warn("ORPHAN_TRANSACTION", "A transaction has no security identifier.", "accounts.transactions", line.location()); return;
        }
        String balanceKey = isin + ":" + folio;
        Balance b = account.balances.computeIfAbsent(balanceKey, ignored -> new Balance(isin, folio));
        if (rest.matches("(?i)^(?:Opening|Closing) Balance.*")) {
            if (!tail.values().isEmpty()) {
                if (rest.toLowerCase(Locale.ROOT).startsWith("opening")) b.open = tail.values().getLast();
                else b.close = tail.values().getLast();
            }
            return;
        }
        var v = tail.values();
        BigDecimal units = null, amount = null, nav = null, price = null, running = null, credit = null, debit = null, stamp = null;
        String description = tail.prefix();
        if (mutualFund && !nativeCdsl && v.size() == 5) {
            amount = v.get(0); stamp = v.get(1); nav = v.get(2); price = v.get(3); units = v.get(4);
        } else if (mutualFund && nativeCdsl && v.size() >= 5) {
            amount = v.get(0); nav = v.get(1); price = v.get(2); units = v.get(3); stamp = v.get(4);
        } else if (!mutualFund && account.type == FileType.NSDL && v.size() == 4) {
            // NSDL corporate-action table: opening, debit, credit, closing.
            if (b.open == null) b.open = v.get(0);
            debit = v.get(1); credit = v.get(2); running = v.get(3); units = zero(credit).subtract(zero(debit));
            b.close = running;
        } else if (!mutualFund && v.size() == 3) {
            credit = v.get(0); debit = v.get(1); running = v.get(2);
            units = zero(credit).subtract(zero(debit));
        } else if (!mutualFund && v.size() == 2) {
            running = v.get(1);
            BigDecimal previous = b.open == null ? null : b.open.add(b.movement);
            if (previous != null && v.get(0) != null && running != null) {
                BigDecimal delta = running.subtract(previous);
                if (delta.abs().subtract(v.get(0).abs()).abs().compareTo(new BigDecimal("0.001")) <= 0) {
                    units = delta;
                    if (delta.signum() >= 0) credit = v.get(0); else debit = v.get(0);
                }
            }
            if (units == null) { context.warn("AMBIGUOUS_TRANSACTION_DIRECTION", "Credit/debit direction could not be reconciled with the running balance.", "accounts.transactions", line.location()); return; }
        } else {
            context.warn("UNPARSED_DEMAT_TRANSACTION", "Transaction columns do not match a supported depository table.", "accounts.transactions", line.location()); return;
        }
        var type = classifier.classify(description, units);
        if (TransactionClassifier.outgoing(type) && units != null) units = units.abs().negate();
        if (type == TransactionType.UNKNOWN && !mutualFund) type = units != null && units.signum() < 0 ? TransactionType.TRANSFER_OUT : TransactionType.TRANSFER_IN;
        if (units != null) b.movement = b.movement.add(units);
        if (running != null && b.open != null && MutualFundState.differs(b.open.add(b.movement), running, "0.001"))
            context.warn("RUNNING_BALANCE_MISMATCH", "Demat transaction units do not match the running balance.", "accounts.transactions", line.location());
        account.transactions.add(new SecurityTransaction(date, isin, folio, description, credit, debit, units, amount, nav, price, running, stamp, type, line.location()));
    }

    private static BigDecimal zero(BigDecimal value) { return value == null ? BigDecimal.ZERO : value; }
    private static AssetType assetHeading(String upper) {
        if (upper.matches("(?:EQUITIES|EQUITY SHARES)(?: \\(E\\))?")) return AssetType.EQUITY;
        if (upper.matches("MUTUAL FUNDS(?: \\(M\\))?")) return AssetType.MUTUAL_FUND;
        if (upper.matches("(?:CORPORATE BONDS|BONDS|GOVERNMENT SECURITIES|SOVEREIGN GOLD BONDS)(?: \\([A-Z]+\\))?")) return AssetType.BOND;
        return null;
    }

    private record SummaryAccount(String name, FileType type, BigDecimal value, int count) {}
    private static final class Balance {
        final String isin, folio;
        BigDecimal open, close, movement = BigDecimal.ZERO;
        Balance(String isin, String folio) { this.isin = isin; this.folio = folio; }
    }
    private static final class Account {
        final String name, dp, client, bo;
        final FileType type;
        final Location source;
        BigDecimal balance;
        int expectedCount = -1;
        final List<Owner> owners = new ArrayList<>();
        final List<Holding> holdings = new ArrayList<>();
        final List<SecurityTransaction> transactions = new ArrayList<>();
        final Map<String, Balance> balances = new LinkedHashMap<>();
        Account(String name, FileType type, String dp, String client, String bo, Location source) {
            this.name = name; this.type = type; this.dp = dp; this.client = client; this.bo = bo; this.source = source;
        }
    }
}
