package com.casparser.parser;

import com.casparser.domain.Statement;
import com.casparser.domain.Statement.CasType;
import com.casparser.domain.Statement.FileType;

/** Implement this interface and register a Spring bean to add a statement dialect. */
public interface StatementParser {
    boolean supports(FileType fileType, CasType casType);
    Statement parse(SourceDocument document, Detection detection, ParseContext context);

    record Detection(FileType fileType, CasType casType) {}
}
