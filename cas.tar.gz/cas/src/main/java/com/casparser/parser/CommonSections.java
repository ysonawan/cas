package com.casparser.parser;

import com.casparser.domain.Statement.*;
import com.casparser.domain.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public final class CommonSections {
    private static final Pattern PERIOD = Pattern.compile("(?i)(" + Values.DATE + ")\\s+(?:to|through|-)\\s+(" + Values.DATE + ")");
    private static final Pattern AS_OF = Pattern.compile("(?i)(?:as\\s+(?:on|of)|valuation\\s+date)\\s*:?\\s*(" + Values.DATE + ")");

    private CommonSections() {}

    public static Period period(SourceDocument document, ParseContext context) {
        String header = String.join("\n", document.lines().stream().limit(70).map(SourceDocument.Line::flat).toList());
        var period = PERIOD.matcher(header);
        try {
            if (period.find()) {
                LocalDate from = Values.date(period.group(1)), to = Values.date(period.group(2));
                if (from.isAfter(to)) context.warn("INVALID_PERIOD", "Statement start date is after its end date.", "statement_period", null);
                return new Period(from, to);
            }
            var asOf = AS_OF.matcher(header);
            if (asOf.find()) return new Period(null, Values.date(asOf.group(1)));
        } catch (IllegalArgumentException ex) {
            context.warn("INVALID_DATE", "The statement period contains an invalid date.", "statement_period", null);
            return new Period(null, null);
        }
        context.warn("MISSING_PERIOD", "The statement period could not be identified.", "statement_period", null);
        return new Period(null, null);
    }

    public static Investor investor(SourceDocument document, ParseContext context) {
        List<String> header = new ArrayList<>();
        for (var line : document.lines()) {
            if (line.location().page() > 3 || header.size() >= 100 || line.flat().matches("(?i).*Folio\\s*(?:No\\.?)?\\s*:.*")) break;
            header.add(line.text().split("\\t", 2)[0].strip());
        }
        String text = String.join("\n", header);
        String email = Values.match(text, "([A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,})", 1);
        String mobile = Values.match(text, "(?:mobile|phone|contact)(?:\\s+no\\.?)?\\s*:?\\s*([+*X0-9][*X0-9 -]{7,18})", 1);
        String pan = Values.match(text, "\\bPAN\\s*:?\\s*([A-Z*]{5}[0-9*]{4}[A-Z*])\\b", 1);
        String name = Values.match(text, "(?m)^(?:investor(?:\\s+name)?|name|first\\s+holder)\\s*:\\s*(.+)$", 1);
        String address = Values.match(text, "(?m)^address\\s*:\\s*(.+)$", 1);
        if (name == null) {
            for (int i = 0; i + 1 < header.size(); i++) {
                if (header.get(i).matches("(?i)^(?:NSDL|CAS) ID\\s*:.*")) {
                    name = header.get(i + 1);
                    List<String> addressLines = new ArrayList<>();
                    for (int j = i + 2; j < header.size(); j++) {
                        String candidate = header.get(j);
                        if (candidate.matches("(?i).*(?:statement for|YOUR CONSOLIDATED|portfolio value).*")) break;
                        addressLines.add(candidate);
                        if (candidate.startsWith("PINCODE")) break;
                    }
                    address = String.join(", ", addressLines);
                    break;
                }
            }
        }
        if (name == null && email != null) {
            for (int i = 0; i + 1 < header.size(); i++) {
                if (header.get(i).contains(email)) {
                    int nameIndex = -1;
                    for (int k = i + 1; k < Math.min(i + 6, header.size()); k++) {
                        if (header.get(k).matches("[A-Z][A-Za-z .'-]{2,80}") && !header.get(k).matches("(?i).*(?:statement|consolidation|investment|friendly).*")) { nameIndex = k; break; }
                    }
                    if (nameIndex < 0) continue;
                    name = header.get(nameIndex);
                    List<String> addressLines = new ArrayList<>();
                    for (int j = nameIndex + 1; j < header.size(); j++) {
                        String candidate = header.get(j);
                        if (candidate.matches("(?i).*(mobile|phone|PAN|folio|mutual fund|statement|date|KYC|PORTFOLIO SUMMARY).*")) break;
                        if (candidate.matches("[A-Z0-9].*") && !candidate.startsWith("If ")) addressLines.add(candidate);
                    }
                    if (!addressLines.isEmpty()) address = String.join(", ", addressLines);
                    break;
                }
            }
        }
        if (name == null) context.warn("MISSING_INVESTOR", "Investor name could not be identified.", "investor_info.name", null);
        return new Investor(name, email, address, mobile, pan);
    }

    public static boolean noise(String text) {
        return text.isBlank() || text.matches("(?i)^" + Values.DATE + "\\s+to\\s+" + Values.DATE + "$")
                || text.matches("(?i)^(?:\\(INR\\).*(?:balance)?|page\\s+\\d+.*|continued.*|date\\s+(?:transaction|description).*|"
                + "transaction\\s+(?:date|details).*|amount\\s*\\(.*|units\\s+nav.*|"
                + "consolidated account (?:statement|summary).*|computer age management.*|"
                + "CAMS|KFINTECH|national securities depository.*|central depository services.*|"
                + "(?:NSDL|CDSL)\\s+CAS.*|statement\\s+(?:period|from).*|for the period.*)$");
    }

    public static Statement finish(FileType type, CasType casType, Period period, Investor investor,
                                    List<Folio> folios, List<DematAccount> accounts, Nps nps,
                                    SourceDocument document, ParseContext context) {
        int transactions = folios.stream().flatMap(f -> f.schemes().stream()).mapToInt(s -> s.transactions().size()).sum()
                + accounts.stream().mapToInt(a -> a.transactions().size()).sum() + (nps == null ? 0 : nps.transactions().size());
        int holdings = accounts.stream().mapToInt(a -> a.holdings().size()).sum()
                + folios.stream().mapToInt(f -> f.schemes().size()).sum() + (nps == null ? 0 : nps.schemes().size());
        if (holdings == 0) throw new com.casparser.domain.ParseException("NO_DATA", 422,
                "A CAS was recognized, but no supported scheme or holding rows could be parsed.", context.warnings());
        return new Statement("1.0", type, casType, context.warnings().isEmpty() ? ParseStatus.COMPLETE : ParseStatus.PARTIAL,
                period, investor, folios, accounts, nps, context.warnings(), new Metadata("1.0.0", document.pages(), transactions, holdings));
    }
}
