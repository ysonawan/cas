package com.casparser.parser;

import java.util.regex.Pattern;
import com.casparser.parser.SourceDocument.Line;

/** Shared CAMS/KFin structural rules, kept separate from transaction/table rules. */
final class MutualFundSections {
    private static final Pattern FOLIO = Pattern.compile("(?i)Folio\\s*(?:No\\.?|Number)?\\s*:?\\s*(\\d[\\d*/-]*(?:\\s*/\\s*\\d+)?)");
    private static final Pattern CODE_SCHEME = Pattern.compile("^([A-Z0-9]{2,20})-\\s*((?i:[A-Za-z].*(?:Fund|Plan|Growth|IDCW|Dividend|ETF).*))$");

    private MutualFundSections() {}

    static boolean structural(Line line, MutualFundState state, ParseContext context) {
        String text = line.flat();
        var folio = FOLIO.matcher(text);
        if (folio.find()) {
            state.selectFolio(folio.group(1));
            folioMetadata(text, state);
            return true;
        }
        if (text.matches("(?i)^(?:AMC\\s*:\\s*)?[A-Za-z][A-Za-z .&()-]+(?:Mutual Fund|MF)(?:\\s*\\(.*\\))?$")) {
            state.amc = text.replaceFirst("(?i)^AMC\\s*:\\s*", "");
            state.folio = null;
            state.scheme = null;
            return true;
        }
        if (state.folio != null && text.matches("(?i)^(?:PAN|KYC|PAN\\s*KYC|Name|Holder|Investor|Folio Holder).*")) {
            folioMetadata(text, state);
            return true;
        }
        if (state.folio != null) {
            String name = Values.match(text, "^Scheme(?:\\s+Name)?\\s*:\\s*(.+)$", 1);
            var coded = CODE_SCHEME.matcher(text);
            String code = null;
            if (name == null && coded.matches()) { name = coded.group(2); code = coded.group(1); }
            if (name != null) {
                String clean = name.replaceFirst("(?i)\\s*(?:-?\\s*\\(?ISIN\\s*:|\\(Advisor\\s*:|\\(ARN[- :]|Registrar\\s*:).*$", "").strip();
                state.selectScheme(clean, code, line.location());
                schemeMetadata(text, state);
                return true;
            }
            if (state.scheme == null && state.folio.name == null && text.matches("[A-Z][A-Za-z .'-]{2,100}")) {
                state.folio.name = text; return true;
            }
        }
        if (state.scheme != null) {
            if (text.matches("(?i)^(?:CAMS|KFINTECH|KARVY)$")) { state.scheme.rta = text; return true; }
            if (schemeMetadata(text, state)) return true;
            var s = state.scheme;
            String open = Values.match(text, "(?:opening|beginning)\\s+(?:unit\\s+)?balance\\s*(?:[:(].*?\\)\\s*)?[: ]*\\s*(" + Values.NUMBER + ")", 1);
            if (open == null) open = Values.match(text, "opening\\s+(?:unit\\s+)?balance[^\\d]*(" + Values.NUMBER + ")", 1);
            if (open != null) { s.open = Values.decimal(open); return true; }
            String close = Values.match(text, "closing\\s+(?:unit\\s+)?balance[^\\d(+-]*(" + Values.NUMBER + ")", 1);
            if (close != null) { s.close = Values.decimal(close); valuation(text, state, context, line); return true; }
            if (valuation(text, state, context, line)) return true;
            if (text.matches("(?i).*(?:no transactions|no transaction during|nil transactions).*")) return true;
        }
        return false;
    }

    private static void folioMetadata(String text, MutualFundState state) {
        var f = state.folio;
        String pan = Values.match(text, "\\bPAN\\s*:?\\s*([A-Z*]{5}[0-9*]{4}[A-Z*])\\b", 1);
        String kyc = Values.match(text, "(?<!PAN )(?<!PAN)\\bKYC\\s*:?\\s*(NOT OK|OK|VALIDATED|REGISTERED|NOT VERIFIED)", 1);
        String panKyc = Values.match(text, "PAN\\s*KYC\\s*:?\\s*(NOT OK|OK|VALIDATED|REGISTERED|NOT VERIFIED)", 1);
        String name = Values.match(text, "(?:^|\\s)(?:Name|Holder|Investor|Folio Holder)(?:\\s+Name)?\\s*:\\s*(.+?)(?=\\s+PAN|\\s+KYC|$)", 1);
        if (pan != null) f.pan = pan;
        if (kyc != null) f.kyc = kyc;
        if (panKyc != null) f.panKyc = panKyc;
        if (name != null) f.name = name;
    }

    private static boolean schemeMetadata(String text, MutualFundState state) {
        var s = state.scheme;
        boolean found = false;
        if (s.partialIsin != null) {
            String suffix = Values.match(text, "^([A-Z0-9]{1,8})(?:\\(|\\s|$)", 1);
            if (suffix != null && Values.ISIN.matcher(s.partialIsin + suffix).matches()) {
                s.isin = s.partialIsin + suffix; s.partialIsin = null; found = true;
            }
        }
        var isin = Values.ISIN.matcher(text);
        if (isin.find()) { s.isin = isin.group(1); found = true; }
        else {
            String partial = Values.match(text, "ISIN\\s*:\\s*(IN[A-Z0-9]{3,9})\\b", 1);
            if (partial != null) { s.partialIsin = partial; found = true; }
        }
        String advisor = Values.match(text, "Advisor\\s*:\\s*([^)]*)", 1);
        if (advisor == null) advisor = Values.match(text, "\\b(ARN[- ]?\\d+|IN[AZ]\\d+|DIRECT)\\b", 1);
        String rta = Values.match(text, "(?:Registrar|RTA)\\s*:\\s*(CAMS|KFINTECH|KARVY)", 1);
        String amfi = Values.match(text, "AMFI(?:\\s+Code)?\\s*:\\s*(\\d+)", 1);
        if (advisor != null) { s.advisor = advisor; found = true; }
        if (rta != null) { s.rta = rta; found = true; }
        if (amfi != null) { s.amfi = amfi; found = true; }
        if (text.matches("(?i)^Nominee.*")) {
            var nominees = Pattern.compile("(?i)Nominee(?:\\s*\\d+)?\\s*:\\s*(.*?)(?=\\s*Nominee|$)").matcher(text);
            while (nominees.find()) for (String value : nominees.group(1).split("\\s*[,;]\\s*")) {
                if (!value.isBlank() && !s.nominees.contains(value.strip())) s.nominees.add(value.strip());
            }
            return true;
        }
        return found;
    }

    private static boolean valuation(String text, MutualFundState state, ParseContext context, Line line) {
        var s = state.scheme;
        boolean found = false;
        String date = Values.match(text, "(?:as\\s+(?:on|of)|NAV\\s+on)\\s*(" + Values.DATE + ")", 1);
        if (date != null) {
            try { s.date = Values.date(date); }
            catch (IllegalArgumentException ex) { context.warn("INVALID_DATE", "Invalid valuation date.", "folios.schemes.valuation", line.location()); }
        }
        String nav = Values.match(text, "\\bNAV(?:\\s+(?:on|as on)\\s+" + Values.DATE + ")?\\s*[:=]\\s*(?:INR|Rs\\.?|₹)?\\s*(" + Values.NUMBER + ")", 1);
        String value = Values.match(text, "(?:market\\s+value|valuation)(?:\\s+(?:as\\s+)?(?:on|of)\\s+" + Values.DATE + ")?\\s*[:=]\\s*(?:INR|Rs\\.?|₹)?\\s*(" + Values.NUMBER + ")", 1);
        String cost = Values.match(text, "(?:total\\s+cost(?:\\s+value)?|cost\\s+value|cost\\s+of\\s+investment|net\\s+cost|invested\\s+amount)\\s*[:=]\\s*(?:INR|Rs\\.?|₹)?\\s*(" + Values.NUMBER + ")", 1);
        if (nav != null) { s.nav = Values.decimal(nav); found = true; }
        if (value != null) { s.value = Values.decimal(value); found = true; }
        if (cost != null) { s.cost = Values.decimal(cost); found = true; }
        return found;
    }
}
