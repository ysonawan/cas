package com.casparser.parser;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Locale-independent statement primitives. No floating point arithmetic. */
public final class Values {
    public static final String DATE = "(?:\\d{1,2}[-/ ](?:[A-Za-z]{3,9}|\\d{1,2})[-/ ]\\d{4}|\\d{4}-\\d{2}-\\d{2})";
    public static final String NUMBER = "(?:[+-]?(?:(?:\\d{1,3}(?:,\\d{2,3})+|\\d+)(?:\\.\\d+)?|\\.\\d+)|\\((?:(?:\\d{1,3}(?:,\\d{2,3})+|\\d+)(?:\\.\\d+)?|\\.\\d+)\\))";
    public static final Pattern ISIN = Pattern.compile("\\b(IN[A-Z0-9]{9}\\d)\\b");
    private static final Pattern DECIMAL = Pattern.compile(NUMBER + "(?:[+-]|\\s*(?:CR|DR))?", Pattern.CASE_INSENSITIVE);
    private static final List<DateTimeFormatter> DATES = List.of(
            formatter("d-MMM-uuuu"), formatter("d-MMMM-uuuu"), formatter("d-M-uuuu"),
            formatter("uuuu-M-d"));

    private Values() {}
    private static DateTimeFormatter formatter(String pattern) {
        return new DateTimeFormatterBuilder().parseCaseInsensitive().appendPattern(pattern)
                .toFormatter(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT);
    }

    public static LocalDate date(String value) {
        String normalized = value.strip().replace('/', '-').replace(' ', '-');
        for (DateTimeFormatter format : DATES) {
            try { return LocalDate.parse(normalized, format); }
            catch (DateTimeParseException ignored) { /* try next supported issuer format */ }
        }
        throw new IllegalArgumentException("Invalid statement date");
    }

    public static BigDecimal decimal(String value) {
        String v = value.strip().replace("₹", "").replaceAll("(?i)^(?:INR|Rs\\.?)\\s*", "").strip();
        if (v.isEmpty() || v.matches("(?i)-+|N/?A|NIL")) return null;
        if (!DECIMAL.matcher(v).matches()) throw new IllegalArgumentException("Invalid statement number");
        boolean negative = v.startsWith("(") || v.endsWith("-") || v.toUpperCase(Locale.ROOT).endsWith("DR");
        v = v.replaceAll("(?i)[(),]|CR|DR", "").strip();
        if (v.endsWith("-") || v.endsWith("+")) v = v.substring(0, v.length() - 1);
        BigDecimal result = new BigDecimal(v);
        return negative ? result.abs().negate() : result;
    }

    public static boolean isNumber(String value) {
        try { decimal(value); return true; }
        catch (IllegalArgumentException ex) { return false; }
    }

    public static String match(String text, String regex, int group) {
        var matcher = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(text);
        return matcher.find() ? matcher.group(group).strip() : null;
    }
}
