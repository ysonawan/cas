package com.casparser.parser;

import com.casparser.domain.Statement.TransactionType;
import java.math.BigDecimal;
import java.util.Locale;

/** Ordered rules: a reversal of a purchase must remain a reversal. */
public final class TransactionClassifier {
    public TransactionType classify(String description, BigDecimal units) {
        String d = description.toLowerCase(Locale.ROOT).replace('-', ' ').replaceAll("\\bs\\s+t\\s+p\\b", "stp");
        boolean outgoing = units != null && units.signum() < 0;
        if (d.matches(".*(?:reversal|reversed|rejected|rejection|dishonou?r|cancelled|cancellation|refund).*")) return TransactionType.REVERSAL;
        if (d.contains("transaction charges")) return TransactionType.FEE;
        if (d.matches("^[* ]*(?:stamp duty).*")) return TransactionType.STAMP_DUTY_TAX;
        if (d.matches("^[* ]*(?:stt\\b|securities transaction tax).*")) return TransactionType.STT_TAX;
        if (d.matches("^[* ]*(?:tds\\b|tax deducted).*")) return TransactionType.TDS_TAX;
        if (d.contains("segregat") || d.contains("side pocket")) return TransactionType.SEGREGATION;
        if (d.contains("gift")) return outgoing || d.matches(".*(?:transfer out|gift out|to folio).*" ) ? TransactionType.GIFT_OUT : TransactionType.GIFT_IN;
        if (d.contains("transmission")) return outgoing || d.contains("out") ? TransactionType.TRANSMISSION_OUT : TransactionType.TRANSMISSION_IN;
        if (d.contains("switch") || d.matches(".*\\bstp\\b.*") || d.contains("merger") || d.contains("systematic transfer") || d.contains("lateral")) {
            boolean out = outgoing || d.matches(".*(?:switch out|switchout|stp out|transfer out|merger out|lateral out).*" );
            if (d.contains("merger")) return out ? TransactionType.SWITCH_OUT_MERGER : TransactionType.SWITCH_IN_MERGER;
            return out ? TransactionType.SWITCH_OUT : TransactionType.SWITCH_IN;
        }
        if (d.contains("transfer in")) return TransactionType.TRANSFER_IN;
        if (d.contains("transfer out")) return TransactionType.TRANSFER_OUT;
        if (d.contains("dividend") || d.contains("idcw")) {
            return d.contains("reinvest") || (units != null && units.signum() > 0)
                    ? TransactionType.DIVIDEND_REINVEST : TransactionType.DIVIDEND_PAYOUT;
        }
        if (d.contains("bonus")) return TransactionType.BONUS;
        if (d.matches(".*(?:redemption|redeem|withdrawal|\\bswp\\b).*")) return TransactionType.REDEMPTION;
        if (d.matches(".*(?:\\bsip\\b|systematic investment|sys\\. investment|instal+ment).*")) return TransactionType.PURCHASE_SIP;
        if (d.matches(".*(?:purchase|subscription|allotment|nfo).*")) return TransactionType.PURCHASE;
        if (d.matches(".*(?:lien|pledge|address|nominee|bank mandate).*")) return TransactionType.MISC;
        return TransactionType.UNKNOWN;
    }

    public static boolean tax(TransactionType type) {
        return type == TransactionType.STAMP_DUTY_TAX || type == TransactionType.STT_TAX || type == TransactionType.TDS_TAX;
    }

    public static boolean outgoing(TransactionType type) {
        return switch (type) {
            case REDEMPTION, SWITCH_OUT, SWITCH_OUT_MERGER, GIFT_OUT, TRANSMISSION_OUT, TRANSFER_OUT -> true;
            default -> false;
        };
    }
}
