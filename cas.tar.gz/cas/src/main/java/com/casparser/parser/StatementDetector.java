package com.casparser.parser;

import com.casparser.domain.ParseException;
import com.casparser.domain.Statement.*;
import com.casparser.parser.StatementParser.Detection;
import java.util.Locale;
import java.util.regex.Pattern;

public final class StatementDetector {
    public Detection detect(SourceDocument document) {
        String text = document.text().toUpperCase(Locale.ROOT);
        String firstPage = String.join("\n", document.lines().stream()
                .filter(l -> l.location().page() == 1).map(SourceDocument.Line::flat).toList())
                .toUpperCase(Locale.ROOT);
        if (!text.contains("CONSOLIDATED ACCOUNT STATEMENT") && !text.contains("CONSOLIDATED ACCOUNT SUMMARY"))
            throw unsupported();
        FileType issuer;
        // A demat CAS can mention both depositories and both RTAs inside its tables.
        // Prefer a full issuer title in the first-page header to account-level mentions.
        String header = firstPage.substring(0, Math.min(firstPage.length(), 1800));
        int nsdl = header.indexOf("NATIONAL SECURITIES DEPOSITORY");
        int cdsl = header.indexOf("CENTRAL DEPOSITORY SERVICES");
        if (nsdl >= 0 || cdsl >= 0) {
            issuer = nsdl >= 0 && (cdsl < 0 || nsdl < cdsl) ? FileType.NSDL : FileType.CDSL;
        } else if (Pattern.compile("(?m)^\\s*(?:NSDL\\s+CAS|NSDL CONSOLIDATED)").matcher(header).find()) {
            issuer = FileType.NSDL;
        } else if (Pattern.compile("(?m)^\\s*(?:CDSL\\s+CAS|CDSL CONSOLIDATED)").matcher(header).find()) {
            issuer = FileType.CDSL;
        } else {
            String meta = String.join(" ", document.metadata().values()).toUpperCase(Locale.ROOT);
            boolean cams = header.contains("COMPUTER AGE MANAGEMENT") || header.contains("CAMSONLINE")
                    || header.contains("BY CAMS AND KFINTECH")
                    || Pattern.compile("(?m)^CAMS(?:\\s|$)").matcher(header).find() || meta.contains("CAMS");
            boolean kfin = header.contains("KFINTECH") || header.contains("KFIN TECHNOLOGIES")
                    || header.contains("KARVY") || meta.contains("KFIN");
            if (cams && kfin) {
                // Joint CAMS/KFin statements are common. Only explicit issuer branding disambiguates.
                int a = header.indexOf("CAMS");
                int b = header.indexOf("KFIN");
                issuer = a >= 0 && (b < 0 || a < b) ? FileType.CAMS : FileType.KFINTECH;
            } else if (cams) issuer = FileType.CAMS;
            else if (kfin) issuer = FileType.KFINTECH;
            else throw unsupported();
        }
        if (issuer == FileType.NSDL || issuer == FileType.CDSL) return new Detection(issuer, CasType.DEMAT);
        boolean detailed = Pattern.compile("(?i)(opening|closing)\\s+(unit\\s+)?balance|transaction\\s+details").matcher(text).find();
        boolean summary = text.contains("SUMMARY") || text.contains("AS ON") || text.contains("AS OF");
        if (!detailed && !summary) throw unsupported();
        return new Detection(issuer, detailed ? CasType.DETAILED : CasType.SUMMARY);
    }

    private ParseException unsupported() {
        return new ParseException("UNSUPPORTED_STATEMENT", 422,
                "The document is not a recognized CAMS, KFintech, NSDL or CDSL CAS layout.");
    }
}
