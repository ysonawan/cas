"use strict";
const form = document.querySelector("#parse-form");
const submit = document.querySelector("#submit");
const section = document.querySelector("#result-section");
const status = document.querySelector("#status");
const result = document.querySelector("#result");
const download = document.querySelector("#download");
let output = null;
form.addEventListener("submit", async event => {
  event.preventDefault();
  submit.disabled = true;
  section.hidden = false;
  download.hidden = true;
  output = null;
  result.textContent = "";
  status.className = "";
  status.textContent = "Reading your statement…";
  const body = new FormData(form);
  body.set("strict", form.elements.strict.checked ? "true" : "false");
  const headers = {};
  const key = document.querySelector("#api-key").value;
  if (key) headers["X-API-Key"] = key;
  try {
    const response = await fetch("/api/v1/statements/parse", {method: "POST", headers, body, cache: "no-store"});
    const content = await response.json();
    result.textContent = JSON.stringify(content, null, 2);
    if (!response.ok) {
      status.className = "error";
      status.textContent = content.detail || "The statement could not be parsed.";
    } else {
      output = result.textContent;
      download.hidden = false;
      status.textContent = content.status === "PARTIAL"
        ? `Parsed with ${content.warnings.length} warning(s). Review the warnings before using these results.`
        : `Parsed ${content.metadata.parsed_holdings} holdings and ${content.metadata.parsed_transactions} transactions.`;
    }
  } catch {
    status.className = "error";
    status.textContent = "Could not reach the parser or read its response. Check that the server is running.";
  } finally {
    submit.disabled = false;
    document.querySelector("#pdf-pass").value = "";
    document.querySelector("#api-key").value = "";
  }
});
download.addEventListener("click", () => {
  if (output === null) return;
  const url = URL.createObjectURL(new Blob([output], {type: "application/json"}));
  const link = document.createElement("a");
  link.href = url;
  link.download = "statement.json";
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
